/* MaleCNS 接管 LIF 网络功能测试 */
const fs = require('fs');
const path = require('path');
const html = fs.readFileSync(__dirname + '/fly_sandbox.html', 'utf8');
const src = html.match(/<script>([\s\S]*?)<\/script>/)[1];
// 提取: 脚本开头(随机数+遗传) → 连接组模板 → LIF → buildMC/stepNetMC (世界之前)
const seg = src.substring(0, src.indexOf('/* ================= 世界'));
const code = seg.replace('"use strict";', '');

const TESTS = `
let pass=0, fail=0;
function T(name, ok, extra){ console.log('['+name+']', ok?'PASS':'FAIL', extra!==undefined?('('+extra+')'):''); ok?pass++:fail++; }

// ===== T01: buildMC 结构完整性 =====
const data = JSON.parse(fs.readFileSync(__dirname+'/data/connectome_demo.json','utf8'));
const MC0 = buildMC(data);
MC = MC0;
T('T01 buildMC 神经元数', MC.N===data.meta.n_neurons, MC.N);
T('T02 buildMC 突触数', MC.CS.length===data.meta.n_synapses, MC.CS.length);

// ===== T03: CSR 索引完整性 =====
let csrOK=true;
let total=0;
for(let i=0;i<MC.N;i++){ if(MC.outOff[i+1]<MC.outOff[i]) csrOK=false; total+=MC.outOff[i+1]-MC.outOff[i]; }
csrOK = csrOK && total===MC.CS.length && MC.outSyn.length===MC.CS.length;
T('T03 CSR outOff/outSyn 覆盖全部突触', csrOK, 'total='+total);

// ===== T04: 感觉入口分配 =====
T('T04 感觉入口>1000', MC.nSens>1000, MC.nSens);
T('T05 输出DN 左右均有', MC.nOutL>10&&MC.nOutR>10, 'L='+MC.nOutL+' R='+MC.nOutR);

// ===== T06: 抑制突触存在 =====
let neg=0; for(let c=0;c<MC.CS.length;c++) if(MC.CW[c]<0) neg++;
T('T06 抑制突触>20%', neg/MC.CS.length>0.2, (100*neg/MC.CS.length).toFixed(1)+'%');

// ===== T07: 感觉注入覆盖所有模态 =====
const mods=['vis','olf','taste','wat','the','avr','aud','phr'];
let modOK=true; for(const m of mods) if(!MC.sl[m]||MC.sl[m].length===0) modOK=false;
T('T07 九类模态全部有入口', modOK, mods.map(m=>m+':'+MC.sl[m].length).join(' '));

// ===== T08: stepNetMC 300 步仿真 — 有发放 =====
const st=newState();
setVisual(0.8,0.4,1.0);
const inp={olf:{L:0.6,R:0.2},wat:{L:0.3,R:0.3},the:{L:0.2,R:0.5},cou:{L:0.1,R:0.1},
           avr:{L:0,R:0},aud:{L:0.2,R:0.2},phr:{L:0.1,R:0.3},taste:0.5};
let totalSpikes=0, sumL=0, sumR=0, nanFound=false;
for(let s=0;s<300;s++){
  const r=stepNet(st,null,inp);
  totalSpikes+=r[0]+r[1]; sumL+=r[0]; sumR+=r[1];
}
for(let i=0;i<MC.N;i++) if(!isFinite(st.V[i])) nanFound=true;
T('T08 300步总尖峰>1000', totalSpikes>1000, totalSpikes);
T('T09 无 NaN', !nanFound);
T('T10 左右输出均有活动', sumL>20&&sumR>20, 'L='+sumL+' R='+sumR);

// ===== T11: 感觉驱动方向性 (左嗅觉强 → 左侧输出应更活跃) =====
const st2=newState();
let L2=0,R2=0;
for(let s=0;s<200;s++){const r=stepNet(st2,null,{olf:{L:0.9,R:0.0},wat:{L:0,R:0},the:{L:0,R:0},cou:{L:0,R:0},avr:{L:0,R:0},aud:{L:0,R:0},phr:{L:0.9,R:0.0},taste:0});
  L2+=r[0];R2+=r[1];}
const st3=newState();
let L3=0,R3=0;
for(let s=0;s<200;s++){const r=stepNet(st3,null,{olf:{L:0.0,R:0.9},wat:{L:0,R:0},the:{L:0,R:0},cou:{L:0,R:0},avr:{L:0,R:0},aud:{L:0,R:0},phr:{L:0.0,R:0.9},taste:0});
  L3+=r[0];R3+=r[1];}
// 左刺激时左侧输出占比 应 > 右刺激时左侧输出占比
const pL1=L2/(L2+R2+1e-9), pL2=L3/(L3+R3+1e-9);
T('T11 嗅觉方位→左右输出差异', pL1>pL2, '左刺激左占比'+(pL1*100).toFixed(0)+'% vs 右刺激'+(pL2*100).toFixed(0)+'%');

// ===== T12: 切回内置连接组 (MC=null) 正常 =====
MC=null;
const st4=newState();  // 内置 396
T('T12 MC=null 恢复内置 N=396', st4.V.length===396, st4.V.length);
console.log('DEBUG inp type:', typeof inp, 'null?', inp===null, 'keys:', inp?Object.keys(inp).join(','):'-');
let sp396=0;
for(let s=0;s<100;s++){const r=stepNet(st4,{},inp);sp396+=r[0]+r[1];}
T('T13 内置网络仍发放', sp396>100, sp396);

console.log('========================================');
console.log('MaleCNS 接管测试: '+pass+' PASS / '+fail+' FAIL');
process.exit(fail>0?1:0);
`;

// 为测试暴露 fs 与 __dirname
const fn = new Function('fs', '__dirname', code + TESTS);
fn(fs, __dirname);
