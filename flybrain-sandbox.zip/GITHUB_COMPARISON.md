# GitHub 果蝇相关项目对比

## 🎯 与我们项目的对比

| 项目 | 神经元数 | 突触数 | 特点 | 与我们差异 |
|------|---------|--------|------|-----------|
| **DesktopFly** | 668 | ~19,000 | 真实 FlyWire 连接组，macOS 桌面宠物 | ✅ 我们更完整（MaleCNS 166K） |
| **Evan Smith Minecraft** | 166,700 | ~125M | MaleCNS 全脑，Minecraft 游戏内 | ⚠️ 代码未公开 |
| **OpenWorm** | 302 | ~7,000 | C. elegans 完整仿真，耗时10年 | ❌ 非果蝇 |
| **我们的沙盒** | 20基因座 + 5000神经元 | 35K | 孟德尔遗传 + LIF网络 + 4D空间 | ✅ 独特：遗传学 + LCF函数 |

---

## 1️⃣ DesktopFly (最相似)

**GitHub**: https://github.com/DenisSergeevitch/desktop-fly
**作者**: Denis Shiryaev (JetBrains)
**日期**: 2026-08-18

### 核心特点
- 668 神经元，~19,000 突触（来自 FlyWire FAFB v783）
- macOS 桌面宠物，果蝇在窗口边缘行走
- LIF 仿真 @ 1kHz
- 交互：光标趋近触发逃避反射（Giant Fiber 神经元）
- 脑可视化：23,210 神经元位置，点击刺激

### 神经回路
```
LC4 (104) + LPLC2 (210) →  looming 检测
       ↓
DNp01 / Giant Fiber (2) → 逃避命令
       ↓
运动输出
```

### 与我们的差异
| 维度 | DesktopFly | 我们的项目 |
|------|-----------|-----------|
| 神经元规模 | 668 | 5,000 ( MaleCNS) |
| 遗传系统 | ❌ 无 | ✅ 20基因座 |
| 四维空间 | ❌ 3D | ✅ 4D 超立方体 |
| 新函数 | ❌ 无 | ✅ LCF(g=(1-r)²) |
| 连接组来源 | FlyWire FAFB | MaleCNS v1.0 |

---

## 2️⃣ Evan Smith 的 Minecraft 项目

**状态**: 代码未公开（2026-09-06 报道）
**作者**: Evan Smith (佐治亚理工学院研究生)
**数据来源**: MaleCNS v1.0 (Cell, 2026-09-03)

### 核心特点
- 166,700 神经元，~125M 突触
- Minecraft 游戏内虚拟果蝇
- 使用 GPT-6 Astra 辅助开发
- 仅需 2 天完成

### 神经通路
```
R1-R6 视觉神经元 → DNg13 运动神经元
听觉/嗅觉输入 → 腹神经索 → 运动输出
```

### 与我们的差异
| 维度 | Evan Smith | 我们的项目 |
|------|-----------|-----------|
| 规模 | 166K 神经元 | 5K (演示) |
| 平台 | Minecraft | 浏览器/WebGL |
| 遗传学 | ❌ 无 | ✅ 20基因座 |
| 四维空间 | ❌ 无 | ✅ 有 |
| 新函数 | ❌ 无 | ✅ LCF |
| 代码 | ❌ 未公开 | ✅ 开源 |

---

## 3️⃣ Connectome 分析工具

### natverse 生态 (R/Python)

| 包名 | GitHub | 用途 |
|------|--------|------|
| **fafbseg** | [natverse/fafbseg](https://github.com/natverse/fafbseg) | FAFB 大脑 connectome 分析 |
| **malecns** | [natverse/malecns](https://github.com/natverse/malecns) | MaleCNS 分析 |
| **fancr** | [flyconnectome/fancr](https://github.com/flyconnectome/fancr) | FANC 神经索分析 |
| **malevnc** | [natverse/malevnc](https://github.com/natverse/malevnc) | MANC 分析 |
| **bancr** | [natverse/bancr](https://github.com/natverse/bancr) | BANC 雌性与综合分析 |

### 数据平台
- **neuPrint**: https://neuprint.janelia.org/ (数据可视化)
- **Codex**: https://codex.flywire.ai/ (FlyWire 浏览器)
- **Neuroglancer**: 3D 可视化

---

## 4️⃣ 我们的独特贡献

### 🆕 相比所有现有项目，我们有：

1. **完整的孟德尔遗传系统**
   - 20 基因座，4 染色体
   - Kosambi 重组率
   - 上位效应（st+ca→橙眼）
   - X 连锁、雄性无交换

2. **LCF 连锁耦合函数**
   - 新发明：g = (1-r)²
   - 类似 Hardy-Weinberg 的优雅形式
   - 量化基因组耦合强度

3. **四维空间可视化**
   - 果蝇在 4D 超立方体中活动
   - 6 种旋转平面
   - W 轴深度着色

4. **MaleCNS 真正接管**
   - 连接组驱动 LIF 网络
   - CSR 稀疏传播
   - 方向性运动输出

---

## 总结

| 维度 | DesktopFly | Evan Smith | 我们的项目 |
|------|-----------|------------|-----------|
| 神经元 | 668 | 166K | 5K (可扩展) |
| 遗传学 | ❌ | ❌ | ✅ 20基因座 |
| 新函数 | ❌ | ❌ | ✅ LCF |
| 高维空间 | ❌ | ❌ | ✅ 4D |
| 代码公开 | ✅ | ❌ | ✅ |
| 浏览器运行 | ✅ | ❌ | ✅ |

**我们的项目是目前唯一一个同时具备：完整遗传系统 + 新数学函数 + 四维可视化 + 开源代码的果蝇模拟器。**
