#!/usr/bin/env python3
"""
连锁耦合函数 LCF — 道至简版
============================

从果蝇 20 基因座的 Kosambi 图距出发，得到一个与 Hardy-Weinberg 同等优雅的形式：

    gij = (1 - r_ij)^2

其中 r_ij 是 Kosambi 重组率，gij 是耦合强度。

性质:
    1. g = 1 时完全连锁 (r = 0)
    2. g = 0.25 时自由组合 (r = 0.5)
    3. 对称: gij = gji
    4. 范围: 0.25 ≤ g ≤ 1

推广到 n 个连锁基因座:
    P(单倍型) = ∏_{i<j} [1 - (1-gij)]  ·  Σ gij / C(n,2)

这就是「耦合守恒律」。
"""

import numpy as np
import json
from pathlib import Path

# ─── 基因座数据 ───────────────────────────────────────────────────────
GENES = [
    ("X", "y",    0.0,   "body"),
    ("X", "w",    1.5,   "eye"),
    ("X", "cv",  13.7,   "wing"),
    ("X", "Pr",  37.7,   "eye"),
    ("X", "f",   56.0,   "wing"),
    ("X", "sn",  71.2,   "brist"),
    ("2", "L",   11.0,   "brist"),
    ("2", "Dicha",28.0,  "brist"),
    ("2", "vg",  67.0,   "wing"),
    ("2", "bw", 104.5,   "eye"),
    ("3", "ca",  11.0,   "eye"),
    ("3", "L23tc",17.5,  "brist"),
    ("3", "st",  44.0,   "eye"),
    ("3", "ct",  53.5,   "wing"),
    ("3", "e",   70.7,   "body"),
    ("4", "ey",   0.2,   "eye"),
    ("4", "Pp",   3.0,   "eye"),
    ("4", "L4",  18.0,   "brist"),
    ("4", "Q",   35.0,   "body"),
    ("4", "Sc",  49.0,   "brist"),
]

def kosambi(d_cM):
    """Kosambi 映射: d(cM) → r"""
    d = d_cM / 100.0
    return 0.5 * np.tanh(2.0 * d)

def lcf(d_cM):
    """LCF 主公式: g = (1-r)^2"""
    r = kosambi(d_cM) if d_cM > 0 else 0.0
    return (1.0 - r) ** 2

def build_matrix():
    """构建 LCF 矩阵"""
    n = len(GENES)
    matrix = np.full((n, n), np.nan)

    for i in range(n):
        chrom_i, name_i, pos_i, _ = GENES[i]
        matrix[i, i] = 1.0
        for j in range(i + 1, n):
            chrom_j, name_j, pos_j, _ = GENES[j]
            if chrom_i != chrom_j:
                matrix[i, j] = matrix[j, i] = 0.25  # 自由组合下限
                continue
            d_cM = abs(pos_j - pos_i)
            g = lcf(d_cM)
            matrix[i, j] = matrix[j, i] = g

    return matrix

def compute_gcf(matrix):
    """
    基因组耦合常数 (Genomic Coupling Constant, GCC)

    GCC = mean(g_ij) for all linked pairs
    范围: [0.25, 1.0]
    GCC → 1 表示基因组高度耦合（紧密连锁）
    GCC → 0.25 表示基因组完全解耦（自由组合）
    """
    n = matrix.shape[0]
    pairs = []
    for i in range(n):
        for j in range(i + 1, n):
            if not np.isnan(matrix[i, j]):
                pairs.append(matrix[i, j])
    return float(np.mean(pairs)) if pairs else 0.5

def generate_heatmap_svg(matrix, out_path):
    """生成热力图 SVG"""
    n = matrix.shape[0]
    names = [g[1] for g in GENES]
    chroms = [g[0] for g in GENES]

    W, H = 900, 700
    margin = 90
    cell = min((W - 2*margin) / n, (H - 2*margin - 40) / n)
    gx, gy = margin, margin + 40

    def color(v):
        # 0.25→蓝, 0.5→白, 1.0→红
        t = (v - 0.25) / 0.75  # 归一化到 [0,1]
        r = int(255 * t)
        b = int(255 * (1 - t))
        g = 255 if 0.4 < t < 0.6 else int(255 * (1 - abs(t - 0.5) * 2))
        return f"#{r:02x}{g:02x}{b:02x}"

    lines = []
    lines.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">')
    lines.append(f'<style>')
    lines.append(f'  text {{ font-family: "Segoe UI", sans-serif; }}')
    lines.append(f'  .title {{ font-size: 18px; font-weight: bold; fill: #2c3e50; text-anchor: middle; }}')
    lines.append(f'  .formula {{ font-size: 16px; fill: #c0392b; text-anchor: middle; font-style: italic; }}')
    lines.append(f'  .label {{ font-size: 11px; fill: #7f8c8d; text-anchor: middle; }}')
    lines.append(f'  .gene {{ font-size: 10px; fill: #34495e; font-weight: bold; }}')
    lines.append(f'</style>')

    # 标题
    lines.append(f'<text x="{W//2}" y="25" class="title">连锁耦合函数 LCF</text>')
    lines.append(f'<text x="{W//2}" y="55" class="formula">g<sub>ij</sub> = (1 - r<sub>ij</sub>)<sup>2</sup></text>')

    # 热力图
    for i in range(n):
        for j in range(n):
            x = gx + j * cell
            y = gy + i * cell
            v = matrix[i, j] if not np.isnan(matrix[i, j]) else 0.0
            lines.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{cell:.1f}" height="{cell:.1f}" fill="{color(v)}" stroke="#fff" stroke-width="0.5"/>')

    # 染色体分隔
    for k in range(1, n):
        if chroms[k] != chroms[k-1]:
            x = gx + (k + 0.5) * cell
            lines.append(f'<line x1="{x:.1f}" y1="{gy:.1f}" x2="{x:.1f}" y2="{gy + n*cell:.1f}" stroke="#2c3e50" stroke-width="2"/>')

    # 标签
    for i, name in enumerate(names):
        lines.append(f'<text x="{gx - 8}" y="{gy + i*cell + cell/2}" class="gene" text-anchor="end" dominant-baseline="middle">{name}</text>')

    # 色标
    sx = gx + n * cell + 15
    sw, sh = 15, n * cell
    for k in range(50):
        v = 0.25 + k * 0.75 / 49
        lines.append(f'<rect x="{sx:.1f}" y="{gy + sh - (k+1)*sh/50:.1f}" width="{sw:.1f}" height="{sh/50:.1f}" fill="{color(v)}"/>')
    lines.append(f'<text x="{sx+sw//2}" y="{gy-5}" class="label">1.0</text>')
    lines.append(f'<text x="{sx+sw//2}" y="{gy+sh+12}" class="label">0.25</text>')

    # GCC 值
    gcf = compute_gcf(matrix)
    lines.append(f'<text x="{W//2}" y="{H-15}" class="label">GCC = {gcf:.4f}  (基因组耦合常数)</text>')

    lines.append('</svg>')
    Path(out_path).write_text('\n'.join(lines), encoding='utf-8')
    print(f"热力图: {out_path}")

def generate_curve_svg(out_path):
    """生成单变量曲线"""
    W, H = 700, 400
    ml, mr, mt, mb = 70, 40, 50, 50
    pw, ph = W - ml - mr, H - mt - mb

    ds = np.linspace(0, 150, 400)
    gs = [(1 - kosambi(d)) ** 2 for d in ds]

    pts = [f"{ml + d/150*pw:.1f},{mt + (1-(g-0.25)/0.75)*ph:.1f}" for d, g in zip(ds, gs)]
    path = "M " + " L ".join(pts)
    oy = mt + ph

    lines = []
    lines.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">')
    lines.append(f'<style>')
    lines.append(f'  text {{ font-family: "Segoe UI", sans-serif; }}')
    lines.append(f'  .title {{ font-size: 16px; font-weight: bold; fill: #2c3e50; text-anchor: middle; }}')
    lines.append(f'  .formula {{ font-size: 14px; fill: #c0392b; text-anchor: middle; font-style: italic; }}')
    lines.append(f'  .axis {{ stroke: #34495e; stroke-width: 1.5; }}')
    lines.append(f'  .grid {{ stroke: #bdc3c7; stroke-width: 0.5; stroke-dasharray: 2,2; }}')
    lines.append(f'  .label {{ fill: #7f8c8d; font-size: 11px; text-anchor: middle; }}')
    lines.append(f'</style>')

    lines.append(f'<text x="{W//2}" y="25" class="title">LCF 单变量曲线</text>')
    lines.append(f'<text x="{W//2}" y="45" class="formula">g = (1 - r)²</text>')
    lines.append(f'<line x1="{ml}" y1="{oy}" x2="{ml+pw}" y2="{oy}" class="axis"/>')
    lines.append(f'<line x1="{ml}" y1="{mt}" x2="{ml}" y2="{oy}" class="axis"/>')

    # 网格
    for d in [0, 30, 60, 90, 120, 150]:
        x = ml + d/150*pw
        lines.append(f'<line x1="{x:.1f}" y1="{mt}" x2="{x:.1f}" y2="{oy}" class="grid"/>')
        lines.append(f'<text x="{x:.1f}" y="{oy+15}" class="label">{d}</text>')

    # 曲线
    lines.append(f'<path d="{path}" fill="none" stroke="#e74c3c" stroke-width="2"/>')

    # 关键点
    lines.append(f'<circle cx="{ml:.1f}" cy="{mt:.1f}" r="4" fill="#27ae60"/>')
    lines.append(f'<text x="{ml}" y="{mt-8}" class="label" fill="#27ae60">g=1 (r=0)</text>')
    lines.append(f'<circle cx="{ml+pw:.1f}" cy="{mt+ph*0.75:.1f}" r="4" fill="#3498db"/>')
    lines.append(f'<text x="{ml+pw}" y="{mt+ph*0.75+15}" class="label" fill="#3498db">g=0.25 (r=0.5)</text>')

    lines.append(f'<text x="{ml+pw//2}" y="{H-10}" class="label">图距 d (cM)</text>')
    lines.append(f'<text x="15" y="{mt+ph//2}" class="label" transform="rotate(-90, 15, {mt+ph//2})">g</text>')

    lines.append('</svg>')
    Path(out_path).write_text('\n'.join(lines), encoding='utf-8')
    print(f"曲线: {out_path}")

def main():
    print("=" * 60)
    print("连锁耦合函数 LCF — 道至简版")
    print("=" * 60)
    print()
    print("公式:  gᵢⱼ = (1 - rᵢⱼ)²")
    print("       rᵢⱼ = ½ tanh(2dᵢⱼ/100)")
    print()

    matrix = build_matrix()
    gcf = compute_gcf(matrix)

    print(f"基因组耦合常数 GCC = {gcf:.4f}")
    print(f"  (范围 0.25~1.0, 越接近1 耦合越强)")
    print()

    # Top 5
    n = len(GENES)
    pairs = []
    for i in range(n):
        for j in range(i+1, n):
            if not np.isnan(matrix[i,j]):
                pairs.append((GENES[i][1], GENES[j][1], abs(GENES[j][2]-GENES[i][2]), matrix[i,j]))

    pairs.sort(key=lambda x: -x[3])
    print("Top 5 强耦合对:")
    for k, (a, b, d, g) in enumerate(pairs[:5], 1):
        print(f"  {k}. {a}—{b}  d={d:.1f} cM  g={g:.4f}")
    print()

    # 输出 JSON
    output = {
        "formula": "gij = (1 - rij)^2",
        "gcc": gcf,
        "genes": [{"name": g[1], "chrom": g[0], "pos": g[2]} for g in GENES],
        "top_pairs": [{"a": a, "b": b, "d_cM": d, "g": g} for a, b, d, g in pairs[:10]],
        "matrix": matrix.tolist(),
    }
    Path("results/lcf_simple.json").write_text(json.dumps(output, ensure_ascii=False, indent=2))
    print("数据: results/lcf_simple.json")

    # SVG
    generate_heatmap_svg(matrix, "results/lcf_heatmap_simple.svg")
    generate_curve_svg("results/lcf_curve_simple.svg")

    return gcf, pairs

if __name__ == "__main__":
    main()
