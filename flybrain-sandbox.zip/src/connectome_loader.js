/* ================================================================
   MaleCNS 连接组加载器 (浏览器端)
   用法: 在 fly_sandbox.html 的 <script> 内引入本文件内容,
   或 <script src="connectome_loader.js"></script>

   数据源: data/connectome.json (由 src/connectome_import.py 生成)
   加载后: 用真实拓扑替换默认 LIF 网络的连接 (CS/CT/CW/CP)
   ================================================================ */

/**
 * 加载连接组 JSON 并重建 LIF 网络
 * @param {string} url  JSON 路径, 默认 'data/connectome.json'
 * @param {object} opts { onProgress(p, msg), onDone(info), onError(err) }
 */
async function loadConnectome(url, opts) {
  opts = opts || {};
  const onProgress = opts.onProgress || function () {};
  try {
    onProgress(0.05, "请求连接组数据 ...");
    const resp = await fetch(url);
    if (!resp.ok) throw new Error("HTTP " + resp.status + " — 先运行 src/connectome_import.py 生成数据");
    onProgress(0.3, "解析 JSON ...");
    const data = await resp.json();

    const nN = data.meta.n_neurons;
    const nS = data.meta.n_synapses;
    onProgress(0.5, "重建 " + nN.toLocaleString() + " 神经元 ...");

    // --- 类型索引表: 按层分组 ---
    const layerOf = new Int8Array(nN);
    const typeOf = new Array(nN);
    for (const nu of data.neurons) {
      layerOf[nu.id] = nu.layer;
      typeOf[nu.id] = nu.type;
    }

    // --- 外部感受器注入位: 各层选取若干感觉入口 ---
    // 层0 神经元作为感觉输入端 (视觉/嗅觉/味觉等按 type 分流)
    const sensory = { vis: [], olf: [], taste: [], wat: [], the: [], avr: [], aud: [], phr: [] };
    for (let i = 0; i < nN; i++) {
      const t = (typeOf[i] || "").toUpperCase();
      if (layerOf[i] !== 0) continue;
      if (/^R[1-8]|^L[1-5]|MI|TM/.test(t)) sensory.vis.push(i);
      else if (/ORN|PHER|DA1|OLF/.test(t)) sensory.olf.push(i);
      else if (/GR|TASTE/.test(t)) sensory.taste.push(i);
      else if (/WGRN|WATER/.test(t)) sensory.wat.push(i);
      else if (/TRP|THERM/.test(t)) sensory.the.push(i);
      else if (/AVR|NOX|PAIN/.test(t)) sensory.avr.push(i);
      else if (/JO|CHORD|AUD/.test(t)) sensory.aud.push(i);
      else sensory.vis.push(i);
    }
    // 层4/5 输出端: DN (决策) 与时钟
    const outputs = { left: [], right: [], clock: [] };
    for (let i = 0; i < nN; i++) {
      const t = (typeOf[i] || "").toUpperCase();
      if (layerOf[i] === 4) {
        if (t.includes("GE1") || t.includes("AM1")) outputs.left.push(i);
        else outputs.right.push(i);
      } else if (layerOf[i] === 5) outputs.clock.push(i);
    }

    onProgress(0.7, "载入 " + nS.toLocaleString() + " 突触 ...");
    // --- 突触 → TypedArray (与 stepNet 兼容) ---
    const CS = new Int32Array(data.synapses.src);
    const CT = new Int32Array(data.synapses.tgt);
    const CW = new Float32Array(data.synapses.w);
    // 递质符号已在导入端编码 (负值=抑制), CP(通路调制)置空
    const CP = new (typeof Uint8Array !== "undefined" ? Uint8Array : Array)(CS.length);

    onProgress(0.9, "重建网络状态 ...");
    // 兼容 fly_sandbox.html 全局: N / CS / CT / CW / CP / NC / NT / NS
    // 完整替换需要重建 NT/NS(类型表) + IDX(感觉注入索引)
    const NT = new Array(nN).fill("MN");            // 统一类型名
    const NS = new Array(nN).fill("C");
    for (let i = 0; i < nN; i++) NS[i] = ["L", "R", "C"][layerOf[i] % 3];

    const info = {
      nNeurons: nN,
      nSynapses: nS,
      neurons: data.neurons,
      layerOf, typeOf, sensory, outputs,
      arrays: { NT, NS, CS, CT, CW, CP },
      meta: data.meta,
    };

    onProgress(1.0, "MaleCNS 拓扑就绪");
    if (opts.onDone) opts.onDone(info);
    return info;
  } catch (err) {
    if (opts.onError) opts.onError(err);
    else console.error("[loadConnectome]", err);
    return null;
  }
}

/**
 * 将加载的连接组应用到运行中的沙盒 (fly_sandbox.html)
 * 策略: 保留原有的感觉注入逻辑, 将突触传播矩阵整体替换为 MaleCNS 拓扑
 */
function applyConnectomeToSandbox(info) {
  // 全局替换 (沙盒脚本使用 var/let 顶层绑定)
  window.CS = info.arrays.CS;
  window.CT = info.arrays.CT;
  window.CW = info.arrays.CW;
  window.CP = info.arrays.CP;
  window.NT = info.arrays.NT;
  window.NS = info.arrays.NS;
  window.N = info.nNeurons;
  window.NC = info.arrays.CS.length;

  // 重建 IDX: 感觉注入索引 (层0 各模态)
  const IDX = {};
  const modalMap = { vis: "vis", olf: "olf", taste: "taste", wat: "wat", the: "the", avr: "avr", aud: "aud", phr: "phr" };
  for (const m in modalMap) IDX[m] = info.sensory[m];
  window.MCNS_IDX = IDX;
  window.MCNS_OUT = info.outputs;

  console.log("[MaleCNS] 已应用: " + info.nNeurons.toLocaleString() + " 神经元 / " +
              info.nSynapses.toLocaleString() + " 突触");
  console.log("[MaleCNS] 感觉入口: 视觉 " + info.sensory.vis.length +
              " 嗅觉 " + info.sensory.olf.length +
              " 味觉 " + info.sensory.taste.length +
              " | 输出: 左DN " + info.outputs.left.length +
              " 右DN " + info.outputs.right.length +
              " 时钟 " + info.outputs.clock.length);
  return true;
}

// 页面加载后自动尝试读取 demo 数据 (存在则提示, 不强制替换)
if (typeof window !== "undefined" && typeof document !== "undefined") {
  window.addEventListener("DOMContentLoaded", () => {
    fetch("data/connectome_demo.json", { method: "HEAD" })
      .then(r => {
        if (r.ok) console.log("[MaleCNS] 检测到 data/connectome_demo.json — 调用 loadConnectome() 加载");
      })
      .catch(() => {});
  });
}
