#!/usr/bin/env python3
"""
连锁耦合函数 (Linkage Coupling Function, LCF)
============================================
一个基于 Kosambi 映射的分数阶指数耦合函数。

定义:
  LCF(i,j) = exp(-λ · d_ij^α) · cos(π · r_ij · β)

其中:
  d_ij = |pos_i - pos_j| / 100   (图距, cM → Morgans)
  r_ij = 0.5 · tanh(2d_ij)       (Kosambi 重组率)
  λ    = 耦合衰减强度 (默认 2.0)
  α    = 距离幂指数 (默认 1.5, 分数阶)
  β    = 相位调制 (默认 1.0)

数学性质:
  1. 当 d→0 (紧密连锁): LCF → cos(0) = 1 (最大耦合)
  2. 当 d→∞ (自由组合): LCF → exp(-∞)·cos(πr) ≈ 0
  3. 振荡结构: cos(π·r_ij·β) 在 r_ij=0.5 处过零
  4. 对称性: LCF(i,j) = LCF(j,i)
"""

import numpy as np
import json
from pathlib import Path

# ─── 基因座数据 ───────────────────────────────────────────────────────
# 格式: (chromosome, name, position_cM, trait_type)
GENES = [
    ("X", "y",    0.0,   "body"),
    ("X", "w",    1.5,   "eye"),
    ("X", "cv",  13.7,   "wing"),
    ("X", "Pr",  37.7,   "eye"),
    ("X", "f",   56.0,   "wing"),
    ("X", "sn",  71.2,   "brist"),
    ("2", "L",   11.0,   "brist"),
    ("2", "Dicha",28.0,  "brist"),
    ("2", "vg",  67.0,   "wing"),
    ("2", "bw", 104.5,   "eye"),
    ("3", "ca",  11.0,   "eye"),
    ("3", "L23tc",17.5,  "brist"),
    ("3", "st",  44.0,   "eye"),
    ("3", "ct",  53.5,   "wing"),
    ("3", "e",   70.7,   "body"),
    ("4", "ey",   0.2,   "eye"),
    ("4", "Pp",   3.0,   "eye"),
    ("4", "L4",  18.0,   "brist"),
    ("4", "Q",   35.0,   "body"),
    ("4", "Sc",  49.0,   "brist"),
]

def kosambi(d_cM):
    """Kosambi 映射函数: d(cM) → 重组率"""
    d = d_cM / 100.0  # cM → Morgans
    return 0.5 * np.tanh(2.0 * d)

def lcf(d_cM, lam=2.0, alpha=1.5, beta=1.0):
    """
    连锁耦合函数 (LCF)

    参数:
      d_cM: 图距 (cM)
      lam:  衰减强度
      alpha: 分数阶幂
      beta:  相位调制

    返回:
      LCF 值 ∈ (-1, 1]
    """
    d = d_cM / 100.0
    r = kosambi(d_cM) if d_cM > 0 else 0.0
    r = min(r, 0.499)  # 上限防止 cos 振荡过于剧烈

    exponential = np.exp(-lam * d**alpha)
    oscillation = np.cos(np.pi * r * beta)

    return exponential * oscillation

def build_matrix(lam=2.0, alpha=1.5, beta=1.0):
    """构建 LCF 矩阵"""
    n = len(GENES)
    matrix = np.zeros((n, n))
    pairs = []

    for i in range(n):
        chrom_i, name_i, pos_i, trait_i = GENES[i]
        for j in range(n):
            if i == j:
                matrix[i,j] = 1.0
                continue

            chrom_j, name_j, pos_j, trait_j = GENES[j]

            if chrom_i != chrom_j:
                matrix[i,j] = 0.0
                continue

            d_cM = abs(pos_j - pos_i)
            gij = lcf(d_cM, lam, alpha, beta)
            matrix[i,j] = gij
            pairs.append({
                "i": name_i, "j": name_j,
                "d_cM": d_cM,
                "gij": float(gij),
                "chrom": chrom_i,
            })

    return matrix, pairs

def generate_svg(matrix, pairs, params, out_path):
    """生成 LCF 热力图 SVG"""
    n = matrix.shape[0]
    gene_names = [g[1] for g in GENES]
    gene_chroms = [g[0] for g in GENES]

    W = 950
    H = 720
    margin = 90
    cell_size = min((W - margin*2) / n, (H - margin*2 - 50) / n)
    grid_w = cell_size * n
    grid_h = cell_size * n
    grid_x = margin
    grid_y = margin + 50

    def val_to_color(v):
        v = max(-1.0, min(1.0, v))
        if v < 0:
            r = int(255 * (1 + v))
            g = int(255 * (1 + v) * 0.5)
            b = 255
        else:
            r = 255
            g = int(255 * (1 - v) * 0.5)
            b = int(255 * (1 - v))
        return f"#{r:02x}{g:02x}{b:02x}"

    lines = []
    lines.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">')
    lines.append(f'<style>')
    lines.append(f'  text {{ font-family: "Segoe UI", sans-serif; font-size: 11px; }}')
    lines.append(f'  .title {{ font-size: 18px; font-weight: bold; fill: #2c3e50; }}')
    lines.append(f'  .subtitle {{ font-size: 12px; fill: #7f8c8d; }}')
    lines.append(f'  .gene-label {{ font-size: 10px; fill: #34495e; }}')
    lines.append(f'</style>')

    lines.append(f'<text x="{W//2}" y="30" text-anchor="middle" class="title">连锁耦合函数 LCF(i,j) 热力图</text>')
    lines.append(f'<text x="{W//2}" y="50" text-anchor="middle" class="subtitle">')
    lines.append(f'LCF = exp(-{params["lam"]:.1f}·d^{params["alpha"]:.1f}) · cos(π·r·{params["beta"]:.1f})')
    lines.append(f'</text>')

    for i in range(n):
        for j in range(n):
            x = grid_x + j * cell_size
            y = grid_y + i * cell_size
            v = matrix[i,j]
            color = val_to_color(v)
            lines.append(f'<rect x="{x:.1f}" y="{y:.1f}" width="{cell_size:.1f}" height="{cell_size:.1f}" fill="{color}" stroke="#fff" stroke-width="0.5"/>')

    # 染色体分隔线
    for k in range(1, n):
        if gene_chroms[k] != gene_chroms[k-1]:
            x = grid_x + (k + 0.5) * cell_size
            lines.append(f'<line x1="{x:.1f}" y1="{grid_y:.1f}" x2="{x:.1f}" y2="{grid_y + grid_h:.1f}" stroke="#34495e" stroke-width="2"/>')

    # 基因标签
    for i, name in enumerate(gene_names):
        x = grid_x - 8
        y = grid_y + i * cell_size + cell_size / 2
        lines.append(f'<text x="{x:.1f}" y="{y:.1f}" text-anchor="end" dominant-baseline="middle" class="gene-label" font-weight="bold">{name}</text>')

    # 色标
    scale_x = grid_x + grid_w + 20
    scale_w = 18
    scale_h = grid_h
    for k in range(100):
        v = -1.0 + 2.0 * k / 99.0
        color = val_to_color(v)
        sy = grid_y + grid_h - (k + 1) * scale_h / 100
        lines.append(f'<rect x="{scale_x:.1f}" y="{sy:.1f}" width="{scale_w:.1f}" height="{scale_h/100:.1f}" fill="{color}"/>')
    lines.append(f'<text x="{scale_x + scale_w//2}" y="{grid_y - 5}" text-anchor="middle" class="gene-label">-1.0</text>')
    lines.append(f'<text x="{scale_x + scale_w//2}" y="{grid_y + grid_h + 12}" text-anchor="middle" class="gene-label">+1.0</text>')
    lines.append(f'<text x="{scale_x + scale_w//2}" y="{grid_y + grid_h//2}" text-anchor="middle" class="gene-label" transform="rotate(-90, {scale_x + scale_w//2}, {grid_y + grid_h//2})">LCF</text>')

    # Top 5
    top5 = sorted([p for p in pairs if p["d_cM"] > 0], key=lambda x: abs(x["gij"]), reverse=True)[:5]
    lines.append(f'<text x="{grid_x}" y="{grid_y + grid_h + 30}" class="subtitle">Top5: ' + ', '.join([f"{p['i']}-{p['j']}" for p in top5]) + '</text>')
    lines.append(f'<text x="{grid_x}" y="{grid_y + grid_h + 48}" class="subtitle">红 = 强耦合 (紧密连锁)  蓝 = 弱耦合 (远距离)  白 = 自耦合 (=1)</text>')

    lines.append('</svg>')

    Path(out_path).write_text('\n'.join(lines), encoding='utf-8')
    print(f"热力图 SVG: {out_path}")

def generate_curve_svg(params, out_path):
    """生成 LCF 单变量曲线 SVG"""
    lam, alpha, beta = params["lam"], params["alpha"], params["beta"]

    W, H = 800, 400
    ml, mr, mt, mb = 70, 40, 60, 50
    pw, ph = W - ml - mr, H - mt - mb

    d_vals = np.linspace(0, 150, 500)
    lcf_vals = [lcf(d, lam, alpha, beta) for d in d_vals]

    pts = []
    for d, v in zip(d_vals, lcf_vals):
        x = ml + (d / 150.0) * pw
        y = mt + (1 - (v + 1) / 2) * ph
        pts.append(f"{x:.1f},{y:.1f}")

    path_d = "M " + " L ".join(pts)
    origin_y = mt + ph

    lines = []
    lines.append(f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">')
    lines.append(f'<style>')
    lines.append(f'  text {{ font-family: "Segoe UI", sans-serif; font-size: 12px; }}')
    lines.append(f'  .title {{ font-size: 16px; font-weight: bold; fill: #2c3e50; }}')
    lines.append(f'  .axis {{ stroke: #34495e; stroke-width: 1.5; }}')
    lines.append(f'  .grid {{ stroke: #bdc3c7; stroke-width: 0.5; stroke-dasharray: 2,2; }}')
    lines.append(f'  .label {{ fill: #7f8c8d; font-size: 11px; }}')
    lines.append(f'</style>')

    lines.append(f'<text x="{W//2}" y="25" text-anchor="middle" class="title">LCF 单变量曲线: LCF(d) vs 图距 d (cM)</text>')
    lines.append(f'<line x1="{ml}" y1="{origin_y}" x2="{ml+pw}" y2="{origin_y}" class="axis"/>')
    lines.append(f'<line x1="{ml}" y1="{mt}" x2="{ml}" y2="{origin_y}" class="axis"/>')

    zero_y = mt + ph / 2
    lines.append(f'<line x1="{ml}" y1="{zero_y:.1f}" x2="{ml+pw}" y2="{zero_y:.1f}" class="grid"/>')
    lines.append(f'<text x="{ml-5}" y="{zero_y:.1f}" text-anchor="end" class="label">0</text>')

    for d in [0, 30, 60, 90, 120, 150]:
        x = ml + (d / 150.0) * pw
        lines.append(f'<line x1="{x:.1f}" y1="{mt}" x2="{x:.1f}" y2="{origin_y}" class="grid"/>')
        lines.append(f'<text x="{x:.1f}" y="{origin_y+15}" text-anchor="middle" class="label">{d}</text>')

    lines.append(f'<path d="{path_d}" fill="none" stroke="#e74c3c" stroke-width="2.5"/>')

    half_r_d = 35
    half_x = ml + (half_r_d / 150.0) * pw
    half_v = lcf(half_r_d, lam, alpha, beta)
    half_y = mt + (1 - (half_v + 1) / 2) * ph
    lines.append(f'<circle cx="{half_x:.1f}" cy="{half_y:.1f}" r="4" fill="#3498db"/>')
    lines.append(f'<text x="{half_x+8}" y="{half_y-8}" class="label" fill="#3498db">半重组点 (d≈35 cM)</text>')

    lines.append(f'<text x="{ml+pw//2}" y="{H-10}" text-anchor="middle" class="label">图距 d (cM)</text>')
    lines.append(f'<text x="15" y="{mt+ph//2}" text-anchor="middle" class="label" transform="rotate(-90, 15, {mt+ph//2})">LCF</text>')
    lines.append(f'<text x="{W-20}" y="{mt+20}" text-anchor="end" class="label">LCF(d) = exp(-{lam}·d^{alpha}) · cos(π·r(d)·{beta})</text>')

    lines.append('</svg>')

    Path(out_path).write_text('\n'.join(lines), encoding='utf-8')
    print(f"曲线 SVG: {out_path}")

def main():
    params = {"lam": 2.0, "alpha": 1.5, "beta": 1.0}

    print("=" * 64)
    print("连锁耦合函数 LCF 计算结果")
    print("=" * 64)
    print(f"参数: λ={params['lam']}, α={params['alpha']}, β={params['beta']}")
    print()

    matrix, pairs = build_matrix(**params)

    same_chrom = [p for p in pairs if p["d_cM"] > 0]
    diff_chrom = [p for p in pairs if p["d_cM"] == 0 and any(g[0] != g[0] for g in GENES)]

    print(f"总配对数: {len(pairs)}")
    print(f"同染色体: {len(same_chrom)} 对")
    print()

    if same_chrom:
        avg_g = np.mean([abs(p["gij"]) for p in same_chrom])
        max_p = max(same_chrom, key=lambda x: abs(x["gij"]))
        min_p = min(same_chrom, key=lambda x: abs(x["gij"]))
        print(f"── LCF 统计 ──")
        print(f"  均值 |gij| = {avg_g:.4f}")
        print(f"  最大值    = {max_p['gij']:+.4f}  ({max_p['i']}-{max_p['j']}, d={max_p['d_cM']:.1f} cM)")
        print(f"  最小值    = {min_p['gij']:+.4f}  ({min_p['i']}-{min_p['j']}, d={min_p['d_cM']:.1f} cM)")
    print()

    print("── Top 10 强耦合 ──")
    sorted_pairs = sorted(same_chrom, key=lambda x: abs(x["gij"]), reverse=True)[:10]
    for idx, p in enumerate(sorted_pairs, 1):
        print(f"  {idx:2d}. {p['i']:>6s} — {p['j']:>6s}  d={p['d_cM']:5.1f} cM  LCF={p['gij']:+.4f}")
    print()

    output = {
        "params": params,
        "matrix": matrix.tolist(),
        "genes": [{"name": g[1], "chrom": g[0], "pos": g[2], "trait": g[3]} for g in GENES],
        "top_pairs": sorted_pairs,
    }
    Path("results/lcf_data.json").parent.mkdir(parents=True, exist_ok=True)
    Path("results/lcf_data.json").write_text(json.dumps(output, ensure_ascii=False, indent=2))
    print("JSON 数据已写入 results/lcf_data.json")

    generate_svg(matrix, pairs, params, "results/lcf_heatmap.svg")
    generate_curve_svg(params, "results/lcf_curve.svg")

if __name__ == "__main__":
    main()
