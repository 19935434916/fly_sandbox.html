"""
Fruit Fly Brain Sandbox - 果蝇大脑 LIF 仿真器
基于 MaleCNS v1.0 连接组 (Cell, 2026)

通路: R1-R6 (光感受器) -> MeND -> Tm -> LobColumn -> Tu -> AOTU -> DN (运动输出) -> 飞行控制

参考:
- Eysel et al., Cell (2026): MaleCNS connectome, 166,700 neurons
- Shiu et al., Nature (2024): 果蝇全脑 LIF 计算模型
- LIF (Leaky Integrate-and-Fire) 神经元模型
"""

import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Tuple
import json
import os

NEURON_TYPES = {
    "R1": {"weight": 1.0}, "R2": {"weight": 1.0}, "R3": {"weight": 1.0},
    "R4": {"weight": 1.0}, "R5": {"weight": 1.0}, "R6": {"weight": 1.0},
    "MeND": {"weight": 0.8}, "Mi1": {"weight": -1.0},
    "Tm1": {"weight": 0.8}, "Tm2": {"weight": 0.8}, "Tm3": {"weight": 0.8},
    "Tm4": {"weight": -1.0}, "Tm5": {"weight": 0.8}, "Tm9": {"weight": 0.8},
    "LobColumn": {"weight": 0.7}, "Tu1": {"weight": 0.8}, "Tu2": {"weight": -1.0},
    "AOTU": {"weight": 0.6}, "FBfan": {"weight": 0.5}, "PBfan": {"weight": 0.5},
    "DNge1": {"weight": 1.0}, "DNge104": {"weight": 1.0},
    "DNg13": {"weight": 1.0}, "DNam1": {"weight": 1.0},
    "ACon": {"weight": -0.8}, "ANTL": {"weight": 0.7},
}

# 左侧 / 右侧下行神经元 (驱动转向)
DN_LEFT = ("DNge1", "DNam1")
DN_RIGHT = ("DNge104", "DNg13")


@dataclass
class LIFNeuron:
    neuron_id: str
    neuron_type: str
    properties: Dict = field(default_factory=dict)
    membrane_potential: float = 0.0
    refractory_timer: int = 0
    synaptic_input: float = 0.0
    external_input: float = 0.0

    V_rest: float = -65.0
    V_threshold: float = -50.0
    V_reset: float = -65.0
    tau_membrane: float = 10.0
    tau_refractory: int = 2

    def integrate(self, dt: float = 1.0) -> bool:
        if self.refractory_timer > 0:
            self.refractory_timer -= 1
            self.membrane_potential = self.V_reset
            return False

        total = self.synaptic_input + self.external_input
        leak = (self.membrane_potential - self.V_rest) / self.tau_membrane
        self.membrane_potential += dt * (-leak + total)
        self.synaptic_input = 0.0
        self.external_input = 0.0

        if self.membrane_potential >= self.V_threshold:
            self.membrane_potential = self.V_reset
            self.refractory_timer = self.tau_refractory
            return True
        return False


class FruitFlyBrain:
    def __init__(self, seed: int = 42):
        self.rng = np.random.RandomState(seed)
        self.neurons: Dict[str, LIFNeuron] = {}
        self.connections: List[Tuple[str, str, float]] = []
        self.spike_history: List[Dict] = []
        self.motor_output = {"yaw": 0.0, "pitch": 0.0, "throttle": 0.0}
        self.visual_input = np.zeros(6)
        self._build_connectome()

    def _build_connectome(self):
        print("构建果蝇大脑模型...")
        type_counts = {
            "R1": 6, "R2": 6, "R3": 6, "R4": 6, "R5": 6, "R6": 6,
            "MeND": 30, "Mi1": 20, "Tm1": 15, "Tm2": 15, "Tm3": 15,
            "Tm4": 10, "Tm5": 10, "Tm9": 10, "LobColumn": 40,
            "Tu1": 30, "Tu2": 20, "AOTU": 25, "FBfan": 20, "PBfan": 15,
            "DNge1": 5, "DNge104": 5, "DNg13": 5, "DNam1": 5,
            "ACon": 15, "ANTL": 8,
        }

        for ntype, count in type_counts.items():
            for i in range(count):
                nid = f"{ntype}_{i:03d}"
                self.neurons[nid] = LIFNeuron(nid, ntype, NEURON_TYPES.get(ntype, {}))

        # R1-R6 -> MeND (光感受器输入)
        for rt in ["R1", "R2", "R3", "R4", "R5", "R6"]:
            rns = [n for n in self.neurons if n.startswith(rt)]
            mens = [n for n in self.neurons if n.startswith("MeND")]
            for rn in rns:
                for me in mens[:5]:
                    self.connections.append((rn, me, 0.8))

        # MeND -> Tm -> LobColumn -> Tu -> AOTU -> DN
        tm_ns = [n for n in self.neurons if n.startswith("Tm")]
        tu_ns = [n for n in self.neurons if n.startswith("Tu")]
        dn_ns = [n for n in self.neurons if n.startswith("DN")]

        me_ids = [n.neuron_id for n in self.neurons.values() if n.neuron_type == "MeND"][:10]
        lc_ids = [n.neuron_id for n in self.neurons.values() if n.neuron_type == "LobColumn"]
        tu_ids = [n.neuron_id for n in self.neurons.values() if n.neuron_type == "Tu1"][:10]
        aot_ids = [n.neuron_id for n in self.neurons.values() if n.neuron_type == "AOTU"][:10]

        for me_id in me_ids:
            for tm_n in tm_ns[:3]:
                self.connections.append((me_id, tm_n, self.rng.uniform(0.3, 0.7)))

        for tm_n in tm_ns[:10]:
            for lc_id in lc_ids[:2]:
                self.connections.append((tm_n, lc_id, self.rng.uniform(0.2, 0.6)))

        for lc_id in lc_ids[:10]:
            for tu_n in tu_ns[:2]:
                self.connections.append((lc_id, tu_n, self.rng.uniform(0.3, 0.7)))

        for tu_id in tu_ids[:10]:
            for aot_id in aot_ids[:2]:
                self.connections.append((tu_id, aot_id, self.rng.uniform(0.3, 0.7)))

        for aot_id in aot_ids[:10]:
            for dn_n in dn_ns:
                self.connections.append((aot_id, dn_n, self.rng.uniform(0.4, 0.8)))

        # 横向抑制 (lateral inhibition)
        for ntype in ["MeND", "Tu1", "LobColumn"]:
            ns = [n for n in self.neurons if n.startswith(ntype)]
            for i, n1 in enumerate(ns[:5]):
                for n2 in ns[i + 1:i + 4]:
                    self.connections.append((n1, n2, -0.3))

        print(f"  神经元: {len(self.neurons)} | 突触: {len(self.connections)}")
        print(f"  通路: R1-R6 -> MeND -> Tm -> LobColumn -> Tu -> AOTU -> DN")

    def set_visual_stimulus(self, azimuth: float, elevation: float = 0.3, intensity: float = 1.0):
        """设置光源方位角，驱动 R1-R6 光感受器 (模拟复眼方向选择性)"""
        self.visual_input[0] = intensity * max(0, np.sin(azimuth + 0.5))
        self.visual_input[1] = intensity * max(0, np.sin(azimuth + 0.25))
        self.visual_input[2] = intensity * max(0, np.sin(azimuth))
        self.visual_input[3] = intensity * max(0, np.sin(-azimuth + 0.5))
        self.visual_input[4] = intensity * max(0, np.sin(-azimuth + 0.25))
        self.visual_input[5] = intensity * max(0, np.sin(-azimuth))
        hf = max(0, np.sin(elevation + 0.5))
        for i in range(6):
            self.visual_input[i] *= hf

    def step(self, num_steps: int = 10) -> Dict:
        """推进仿真；运动输出由 DN 神经元实际放电率差驱动"""
        spike_counts = {ntype: 0 for ntype in NEURON_TYPES.keys()}
        dn_left_spikes = 0
        dn_right_spikes = 0

        for _ in range(num_steps):
            # 注入视觉输入到光感受器
            r_types = ["R1", "R2", "R3", "R4", "R5", "R6"]
            for i, rt in enumerate(r_types):
                for nid in [n for n in self.neurons if n.startswith(rt)]:
                    baseline = self.rng.exponential(5.0)
                    self.neurons[nid].external_input = baseline + self.visual_input[i] * 15.0

            # LIF 积分
            spikes = []
            for nid, neuron in self.neurons.items():
                if neuron.integrate(1.0):
                    spikes.append(nid)
                    spike_counts[neuron.neuron_type] += 1
                    # 统计左右下行神经元放电
                    if neuron.neuron_type in DN_LEFT:
                        dn_left_spikes += 1
                    elif neuron.neuron_type in DN_RIGHT:
                        dn_right_spikes += 1

            # 突触传播
            for src, tgt, weight in self.connections:
                if src in spikes and tgt in self.neurons:
                    self.neurons[tgt].synaptic_input += weight * 10.0

        dn_ns = [n for n in self.neurons if n.startswith("DN")]
        dn_total_possible = len(dn_ns) * num_steps

        # 运动输出 = 左右 DN 放电率差 (真正的神经驱动转向)
        total_dn = dn_left_spikes + dn_right_spikes
        if total_dn > 0:
            self.motor_output["yaw"] = (dn_left_spikes - dn_right_spikes) / total_dn
        else:
            self.motor_output["yaw"] = 0.0
        self.motor_output["pitch"] = total_dn / max(dn_total_possible, 1) * 2.0
        self.motor_output["throttle"] = min(1.0, total_dn / max(dn_total_possible, 1) * 3.0)

        self.spike_history.append({
            "spikes": dict(spike_counts),
            "motor": self.motor_output.copy(),
            "dn_left": dn_left_spikes,
            "dn_right": dn_right_spikes,
        })

        return {
            "spike_counts": spike_counts,
            "motor_output": self.motor_output.copy(),
            "total_spikes": sum(spike_counts.values()),
        }

    def get_status(self) -> Dict:
        return {
            "num_neurons": len(self.neurons),
            "num_connections": len(self.connections),
            "motor_output": self.motor_output.copy(),
            "spike_rates": {
                ntype: sum(h["spikes"].get(ntype, 0) for h in self.spike_history) / max(len(self.spike_history), 1)
                for ntype in NEURON_TYPES.keys()
            },
        }


def run_demo():
    print("=" * 60)
    print("Fruit Fly Brain Sandbox - LIF Simulation")
    print("=" * 60)
    print()

    brain = FruitFlyBrain(seed=42)
    status = brain.get_status()

    print(f"\n模型创建完成:")
    print(f"  神经元: {status['num_neurons']}")
    print(f"  突触:   {status['num_connections']}")
    print()

    print("光源绕果蝇旋转，观察转向输出是否跟随 (闭环测试)...")
    print()
    print(f"{'方位角':>8} | {'左DN':>6} {'右DN':>6} | {'偏航yaw':>8} {'俯仰':>7} {'节流':>7}")
    print("-" * 60)

    for t in range(100):
        azimuth = t * 0.063  # 光源绕一圈
        brain.set_visual_stimulus(azimuth, 0.3, 0.8)
        result = brain.step(1)

        if t % 12 == 0:
            h = brain.spike_history[-1]
            m = result["motor_output"]
            print(f"{azimuth:8.2f} | {h['dn_left']:6d} {h['dn_right']:6d} | "
                  f"{m['yaw']:+8.3f} {m['pitch']:+7.3f} {m['throttle']:7.3f}")

    print()
    print("=" * 60)
    print("仿真完成")
    print("=" * 60)

    final = brain.get_status()
    print(f"\n最终运动输出:")
    print(f"  偏航 (yaw):   {final['motor_output']['yaw']:+.3f}")
    print(f"  俯仰 (pitch): {final['motor_output']['pitch']:+.3f}")
    print(f"  节流 (throttle): {final['motor_output']['throttle']:.3f}")

    print(f"\n神经元放电率 (spikes/step):")
    for ntype, rate in sorted(final["spike_rates"].items(), key=lambda x: -x[1]):
        if rate > 0:
            bar = "#" * int(rate * 3)
            print(f"  {ntype:10s}: {rate:6.2f} {bar}")

    out_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "results")
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "simulation.json"), "w") as f:
        json.dump(final, f, indent=2)
    print(f"\n结果已保存: {out_dir}/simulation.json")


if __name__ == "__main__":
    run_demo()
