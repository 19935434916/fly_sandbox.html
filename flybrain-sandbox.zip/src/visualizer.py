"""
果蝇大脑仿真可视化器
显示神经网络活动和果蝇运动状态
"""

import sys
import os
sys.path.insert(0, os.path.dirname(__file__))

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.animation import FuncAnimation
from brain_model import FruitFlyBrain, NEURON_TYPES


class BrainVisualizer:
    """果蝇大脑活动的实时可视化"""
    
    def __init__(self, brain: FruitFlyBrain, fig_size=(14, 10)):
        self.brain = brain
        self.fig = plt.figure(figsize=fig_size)
        self.fig.suptitle("Fruit Fly Brain Simulation - MaleCNS Inspired Model", 
                         fontsize=14, fontweight='bold')
        
        # 创建子图布局
        self.ax_neurons = plt.subplot(2, 2, (1, 3))  # 神经元活动热力图
        self.ax_motor = plt.subplot(2, 2, 4)          # 运动输出仪表盘
        self.ax_spikes = plt.subplot(2, 1, 2)         # 放电率时间序列
        
        self.fig.tight_layout(rect=[0, 0.03, 1, 0.95])
        
        # 存储数据用于动画
        self.spike_history = []
        self.motor_history = {"yaw": [], "pitch": [], "throttle": []}
        self.heat_data = np.zeros((len(NEURON_TYPES), 10))
        
        # 设置初始绘图
        self._setup_plots()
    
    def _setup_plots(self):
        """设置初始图表"""
        # 1. 神经元活动热力图
        ntypes = list(NEURON_TYPES.keys())
        self.heatmap = self.ax_neurons.imshow(
            self.heat_data.T, 
            aspect='auto', 
            cmap='viridis',
            vmin=0, 
            vmax=1
        )
        self.ax_neurons.set_xticks(range(len(ntypes)))
        self.ax_neurons.set_xticklabels([nt[:4] for nt in ntypes], rotation=45, ha='right', fontsize=8)
        self.ax_neurons.set_yticks(range(10))
        self.ax_neurons.set_yticklabels([f"t-{10-i}" for i in range(10)])
        self.ax_neurons.set_title("Neuron Type Activity Heatmap")
        self.ax_neurons.set_xlabel("Neuron Type")
        self.ax_neurons.set_ylabel("Time (steps back)")
        
        # 2. 运动输出仪表盘
        self.ax_motor.set_xlim(-2, 2)
        self.ax_motor.set_ylim(-2, 2)
        self.ax_motor.set_aspect('equal')
        self.ax_motor.axis('off')
        self.ax_motor.set_title("Flight Control Output")
        
        # 绘制圆形仪表盘
        circle = plt.Circle((0, 0), 1.5, fill=False, color='gray', linewidth=2)
        self.ax_motor.add_patch(circle)
        
        # 偏航指示器 (水平)
        self.yaw_needle = plt.Line2D([0, 0], [0, 0], color='red', linewidth=3)
        self.ax_motor.add_line(self.yaw_needle)
        
        # 俯仰指示器 (垂直)
        self.pitch_needle = plt.Line2D([0, 0], [0, 0], color='blue', linewidth=3)
        self.ax_motor.add_line(self.pitch_needle)
        
        # 节流指示器 (中心点大小)
        self.throttle_dot = plt.Circle((0, 0), 0.1, color='green')
        self.ax_motor.add_patch(self.throttle_dot)
        
        # 标注
        self.ax_motor.text(0, -1.8, "Yaw (Left↔Right)", ha='center', fontsize=9)
        self.ax_motor.text(1.8, 0, "Pitch", ha='left', fontsize=9)
        self.ax_motor.text(0, 1.8, f"Throttle: {self.brain.motor_output['throttle']:.2f}", 
                          ha='center', fontsize=9)
        
        # 3. 放电率时间序列
        self.ax_spikes.set_xlabel("Time (steps)")
        self.ax_spikes.set_ylabel("Spike Rate (spikes/step)")
        self.ax_spikes.set_title("Visual Pathway Activity Over Time")
        
        # 初始化空线图
        self.line_r = self.ax_spikes.plot([], [], 'r-', label='R1-R6 (Photoreceptors)', linewidth=2)[0]
        self.line_me = self.ax_spikes.plot([], [], 'g-', label='MeND (Medulla)', linewidth=2)[0]
        self.line_tu = self.ax_spikes.plot([], [], 'b-', label='Tu (Lobula)', linewidth=2)[0]
        self.line_dn = self.ax_spikes.plot([], [], 'm-', label='DN (Motor Output)', linewidth=2)[0]
        self.ax_spikes.legend(loc='upper right', fontsize=8)
        self.ax_spikes.grid(True, alpha=0.3)
    
    def update(self, frame):
        """更新一帧动画"""
        # 运行仿真
        result = self.brain.step(num_steps=5)
        
        # 更新视觉输入 (模拟光源旋转)
        azimuth = frame * 0.03
        self.brain.set_visual_stimulus((azimuth, 0.3), intensity=0.7)
        
        # 更新热力图数据
        spike_rates = result["spike_counts"]
        ntypes = list(NEURON_TYPES.keys())
        new_row = np.array([spike_rates.get(nt, 0) for nt in ntypes])
        new_row = new_row / max(new_row.max(), 1)  # 归一化
        self.heat_data = np.roll(self.heat_data, 1, axis=1)
        self.heat_data[:, 0] = new_row
        self.heatmap.set_data(self.heat_data.T)
        
        # 更新运动输出
        motor = result["motor_output"]
        self.yaw_needle.set_data([0, motor['yaw'] * 1.5], [0, 0])
        self.pitch_needle.set_data([0, 0], [0, motor['pitch'] * 1.5])
        self.throttle_dot.set_center((motor['yaw'] * 0.5, motor['pitch'] * 0.5))
        self.throttle_dot.set_radius(0.05 + motor['throttle'] * 0.15)
        self.ax_motor.texts[2].set_text(f"Throttle: {motor['throttle']:.2f}")
        
        # 更新时间序列
        self.spike_history.append({
            'r': sum(spike_rates.get(nt, 0) for nt in ['R1', 'R2', 'R3', 'R4', 'R5', 'R6']),
            'me': spike_rates.get('MeND', 0),
            'tu': spike_rates.get('Tu1', 0) + spike_rates.get('Tu2', 0),
            'dn': sum(spike_rates.get(nt, 0) for nt in ['DNge1', 'DNge104', 'DNg13', 'DNam1'])
        })
        
        history = self.spike_history[-50:]  # 只显示最近50步
        steps = list(range(len(history)))
        
        self.line_r.set_data(steps, [h['r'] for h in history])
        self.line_me.set_data(steps, [h['me'] for h in history])
        self.line_tu.set_data(steps, [h['tu'] for h in history])
        self.line_dn.set_data(steps, [h['dn'] for h in history])
        
        self.ax_spikes.set_xlim(0, min(50, len(self.spike_history)))
        self.ax_spikes.set_ylim(0, max([max(h['r'], h['me'], h['tu'], h['dn']) for h in history] + [1]))
        
        return self.heatmap, self.yaw_needle, self.pitch_needle, self.throttle_dot
    
    def run(self, frames=100, interval=50):
        """运行动画"""
        self.anim = FuncAnimation(
            self.fig, 
            self.update, 
            frames=frames,
            interval=interval,
            blit=False
        )
        plt.show()


def main():
    """主函数"""
    print("启动果蝇大脑仿真可视化...")
    print("按 Ctrl+C 停止")
    print()
    
    # 创建大脑
    brain = FruitFlyBrain(num_neurons=400, seed=42)
    
    # 创建可视化器
    visualizer = BrainVisualizer(brain)
    
    # 运行动画
    try:
        visualizer.run(frames=200, interval=30)
    except KeyboardInterrupt:
        print("\n仿真已停止")
    
    # 保存静态图
    output_path = "/c/Users/zhaok/WorkBuddy/2026-09-07-16-45-34/flybrain-sandbox/results/brain_activity.png"
    brain.reset()
    for _ in range(50):
        brain.step(num_steps=10)
    
    final_status = brain.get_status()
    
    fig, axes = plt.subplots(2, 2, figsize=(14, 10))
    fig.suptitle("Fruit Fly Brain Simulation - Final State", fontsize=14, fontweight='bold')
    
    # 1. 神经元类型放电率柱状图
    rates = sorted(final_status['spike_rates'].items(), key=lambda x: -x[1])
    ntypes, rates_val = zip(*rates[:15])  # 前15个
    axes[0, 0].barh(range(len(ntypes)), rates_val, color='steelblue')
    axes[0, 0].set_yticks(range(len(ntypes)))
    axes[0, 0].set_yticklabels([nt[:6] for nt in ntypes], fontsize=9)
    axes[0, 0].set_xlabel("Spike Rate (spikes/step)")
    axes[0, 0].set_title("Top 15 Neuron Types by Activity")
    axes[0, 0].invert_yaxis()
    
    # 2. 视觉通路活动
    visual_types = ["R1", "R2", "R3", "R4", "R5", "R6", "MeND", "Mi1", "Tm1", "Tm2"]
    vis_rates = [final_status['spike_rates'].get(nt, 0) for nt in visual_types]
    axes[0, 1].bar(range(len(visual_types)), vis_rates, color=['red']*6 + ['orange']*4)
    axes[0, 1].set_xticks(range(len(visual_types)))
    axes[0, 1].set_xticklabels(visual_types, rotation=45)
    axes[0, 1].set_ylabel("Spike Rate")
    axes[0, 1].set_title("Visual Pathway Activity (R1-R6 → MeND → Tm)")
    axes[0, 1].grid(True, alpha=0.3)
    
    # 3. 运动输出
    motor = final_status['motor_output']
    axes[1, 0].pie([abs(motor['yaw']), abs(motor['pitch']), motor['throttle']], 
                   labels=['Yaw', 'Pitch', 'Throttle'], 
                   colors=['red', 'blue', 'green'],
                   autopct='%1.1f%%')
    axes[1, 0].set_title("Flight Control Distribution")
    
    # 4. 连接统计
    type_counts = {}
    for nid, neuron in brain.neurons.items():
        type_counts[neuron.neuron_type] = type_counts.get(neuron.neuron_type, 0) + 1
    
    axes[1, 1].bar(range(len(type_counts)), list(type_counts.values()))
    axes[1, 1].set_xticks(range(len(type_counts)))
    axes[1, 1].set_xticklabels(list(type_counts.keys()), rotation=45, ha='right', fontsize=8)
    axes[1, 1].set_ylabel("Number of Neurons")
    axes[1, 1].set_title("Neuron Type Distribution")
    axes[1, 1].grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=150, bbox_inches='tight')
    print(f"\n静态图已保存到: {output_path}")
    
    # 打印摘要
    print("\n" + "=" * 60)
    print("仿真摘要")
    print("=" * 60)
    print(f"神经元总数: {brain.num_neurons}")
    print(f"突触连接数: {len(brain.connections)}")
    print(f"仿真时长: 200 步")
    print(f"总放电数: {len(brain.spike_history) * brain.num_neurons * 0.3:.0f} (估算)")
    print(f"\n最终运动输出:")
    print(f"  偏航 (yaw):   {motor['yaw']:+.3f}")
    print(f"  俯仰 (pitch): {motor['pitch']:+.3f}")
    print(f"  节流: {motor['throttle']:.3f}")


if __name__ == "__main__":
    main()
