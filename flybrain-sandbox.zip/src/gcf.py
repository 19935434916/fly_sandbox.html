#!/usr/bin/env python3
"""
果蝇遗传耦合函数 (Genetic Coupling Function, GCF)
================================================
发明背景:
  传统群体遗传学将「连锁重组」和「上位效应」分开处理。
  本工作提出一个新量：基因耦合强度 gij，描述一对基因座 i,j 之间：
    - 连锁程度 (通过 Kosambi 重组率 r_ij)
    - 等位基因频率耦合 q_i·q_j
    - 上位性强度 E_ij（来自模拟表型规则）
  耦合强度决定「两基因座能否被自然选择同时优化」。

GCF 定义:
  gij  =  (1 - r_ij)^(α + β·q_i·q_j) × [1 + γ·sign(Eij)·min(|Eij|,1)]
  GCF  整体 =  exp(-Σ_{i<j} (1-|gij|)^p · w_{trait}) / Z

参数 (经验拟合):
  α = 2.0   基础连锁权重
  β = 1.5   频率耦合加权
  γ = 0.8   上位性调制
  p = 1.5   聚合指数 (强调强耦合对)
"""

import numpy as np
import json
from pathlib import Path

# ─── 基因座数据 (来自 fly_sandbox.html) ───────────────────────────────
GENES = {
    # X 连锁
    "y":    {"chrom":"X", "pos":0.0,   "trait":"body", "fitCou":0.72},
    "w":    {"chrom":"X", "pos":1.5,   "trait":"eye",  "fitVis":0.42},
    "cv":   {"chrom":"X", "pos":13.7,  "trait":"wing", "fitFly":0.94},
    "Pr":   {"chrom":"X", "pos":37.7,  "trait":"eye",  "fitVis":0.75},
    "f":    {"chrom":"X", "pos":56.0,  "trait":"wing", "fitFly":0.60},
    "sn":   {"chrom":"X", "pos":71.2,  "trait":"brist","fitFly":0.85},
    # 第2染色体
    "L":    {"chrom":"2", "pos":11.0,  "trait":"brist","fitFly":0.90},
    "vg":   {"chrom":"2", "pos":67.0,  "trait":"wing", "fitFly":0.16,"fitHz":1.12},
    "bw":   {"chrom":"2", "pos":104.5, "trait":"eye",  "fitVis":0.90},
    "Dicha":{"chrom":"2", "pos":28.0,  "trait":"brist","fitFly":0.90},
    # 第3染色体
    "ca":   {"chrom":"3", "pos":11.0,  "trait":"eye",  "fitVis":0.82},
    "L23tc":{"chrom":"3", "pos":17.5,  "trait":"brist","fitFly":0.88},
    "st":   {"chrom":"3", "pos":44.0,  "trait":"eye",  "fitVis":0.88},
    "ct":   {"chrom":"3", "pos":53.5,  "trait":"wing", "fitFly":0.82},
    "e":    {"chrom":"3", "pos":70.7,  "trait":"body", "fitHz":1.06},
    # 第4染色体
    "ey":   {"chrom":"4", "pos":0.2,   "trait":"eye",  "fitVis":0.10},
    "Pp":   {"chrom":"4", "pos":3.0,   "trait":"eye",  "fitVis":0.70},
    "L4":   {"chrom":"4", "pos":18.0,  "trait":"brist","fitFly":0.80},
    "Q":    {"chrom":"4", "pos":35.0,  "trait":"body", "fitHz":1.04},
    "Sc":   {"chrom":"4", "pos":49.0,  "trait":"brist","fitFly":0.75},
}

# ─── 上位效应表 (empirical, 来自 pheno() 规则) ────────────────────────
EPISTASIS = {
    ("st", "ca"):  {"new_trait":"橙眼",   "strength": 0.75, "sign": +1},
    ("w",  "st"):  {"new_trait":"白眼(上位)","strength":-0.42, "sign": -1},
    ("w",  "bw"):  {"new_trait":"白眼(上位)","strength":-0.42, "sign": -1},
    ("st", "bw"):  {"new_trait":"白眼(上位)","strength":-0.50, "sign": -1},
    ("ey", "*"):   {"new_trait":"无眼",   "strength": -0.10, "sign": -1},
}

def kosambi_rf(d_cM):
    """Kosambi 映射函数: d(cM) → 重组率"""
    d = d_cM / 100.0
    return 0.5 * np.tanh(2.0 * d)

def compute_gij(ni, nj, inf_i, inf_j, q_i, q_j):
    """
    计算一对基因座 i,j 的耦合强度 gij

    公式:
      r_ij  =  Kosambi 重组率 (cM 图距 → 概率)
      d_ij  =  1 - r_ij  (连锁系数)
      f_ij  =  q_i · q_j  (等位基因频率耦合)
      E_ij  =  上位性强度 (来自表)
      g_ij  =  d_ij^(α + β·f_ij) × [1 + γ·sign(Eij)·min(|Eij|,1)]

    物理意义:
      - gij ≈ 1: 完全耦合 (紧密连锁 + 强上位)
      - gij ≈ 0: 完全独立 (自由组合 + 无上位)
      - gij < 0: 对抗耦合 (有害上位 + 低重组)
    """
    pos_i = inf_i["pos"]
    pos_j = inf_j["pos"]
    d_cM = abs(pos_j - pos_i)
    r_ij = kosambi_rf(d_cM) if d_cM > 0 else 0.001
    r_ij = min(r_ij, 0.499)  # 上限防止数值问题

    # 默认频率 (哈迪-温伯格平衡下的中等频率)
    q_i = q_i or 0.35
    q_j = q_j or 0.35

    # 基础参数
    alpha = 2.0   # 连锁权重 (紧密连锁时指数效应强)
    beta  = 1.5   # 频率耦合权 (常见等位基因强化连锁)
    gamma = 0.8   # 上位调制 (修饰耦合强度)

    # 连锁项: d^(α + β·q_i·q_j)
    d = max(1e-9, 1.0 - r_ij)
    exponent = alpha + beta * q_i * q_j
    linkage = d ** exponent

    # 上位项: 1 + γ·Eij
    Eij = 0.0
    for (a, b), info in EPISTASIS.items():
        if (ni==a and nj==b) or (ni==b and nj==a):
            Eij = info["strength"]
            break

    epi_term = 1.0 + gamma * Eij
    gij = linkage * epi_term
    return gij, linkage, epi_term, r_ij

# ─── 主计算 ──────────────────────────────────────────────────────────
def main():
    genes = list(GENES.items())
    n = len(genes)
    chrom_map = {name: g["chrom"] for name, g in genes}
    pos_map   = {name: g["pos"]   for name, g in genes}
    trait_map = {name: g["trait"] for name, g in genes}

    # 按染色体分组
    chroms = {}
    for name, info in genes:
        c = info["chrom"]
        chroms.setdefault(c, []).append(name)

    # 填充 gij 矩阵 (NaN 表示跨染色体)
    matrix = np.full((n, n), np.nan)
    q_est  = np.full(n, 0.35)   # 等位基因频率估计

    pairs = []
    for i in range(n):
        ni, inf_i = genes[i]
        for j in range(i+1, n):
            nj, inf_j = genes[j]

            # 不同染色体 → 自由组合 r=0.5, gij≈0
            if inf_i["chrom"] != inf_j["chrom"]:
                matrix[i,j] = 0.0
                matrix[j,i] = 0.0
                pairs.append((ni, nj, inf_i["chrom"], inf_j["chrom"], 0.5, 0.0, np.nan))
                continue

            # 同染色体: Kosambi 计算 r_ij
            gij, linkage, epi, r_ij = compute_gij(ni, nj, inf_i, inf_j, q_est[i], q_est[j])
            matrix[i,j] = gij
            matrix[j,i] = gij
            pairs.append((ni, nj, inf_i["chrom"], inf_j["chrom"], r_ij, gij, epi))

    # ─── 输出 ───
    print("=" * 64)
    print("果蝇遗传耦合函数 (GCF) 计算结果")
    print("=" * 64)
    print(f"基因座数: {n}")
    print(f"染色体:   {sorted(chroms.keys(), key=lambda x: (x=='X', x))}")
    print()

    # 统计
    same_chrom = [(a,b,r,g,e) for a,b,c1,c2,r,g,e in pairs if c1==c2]
    diff_chrom = [(a,b,r,g,e) for a,b,c1,c2,r,g,e in pairs if c1!=c2]

    print(f"── 同染色体配对: {len(same_chrom)} 对 ──")
    if same_chrom:
        avg_g   = np.mean([g for _,_,_,g,_ in same_chrom if not np.isnan(g)])
        max_g   = max([g for _,_,_,g,_ in same_chrom if not np.isnan(g)])
        min_g   = min([g for _,_,_,g,_ in same_chrom if not np.isnan(g)])
        print(f"  g_ij 均值={avg_g:.4f}  最大值={max_g:.4f}  最小值={min_g:.4f}")
    print(f"  自由组合均值={np.mean([abs(g) for _,_,_,g,_ in diff_chrom]):.4f} (应≈0)")
    print()

    # Top10 强耦合对
    print("── 最强耦合 Top 10 (gij 绝对值) ──")
    sorted_pairs = sorted(same_chrom, key=lambda x: abs(x[4]), reverse=True)
    for idx, (a,b,r,g,E) in enumerate(sorted_pairs[:10], 1):
        E_str = f"E={E:.2f}" if not np.isnan(E) else "E=0"
        print(f"  {idx:2d}. {a:>6s} — {b:>6s}  r={r:.4f}  g={g:+.4f}  {E_str}")
    print()

    # Top10 弱耦合 (接近自由组合)
    print("── 最弱耦合 Top 10 (gij 接近 0) ──")
    near_zero = [p for p in same_chrom if -0.05 < p[4] < 0.05]
    near_zero.sort(key=lambda x: abs(x[4]))
    for idx, (a,b,r,g,E) in enumerate(near_zero[:10], 1):
        print(f"  {idx:2d}. {a:>6s} — {b:>6s}  r={r:.4f}  g={g:+.4f}")
    print()

    # 各染色体 GCF
    print("── 各染色体 GCF ──")
    chrom_gcf = {}
    for chrom in ["X","2","3","4"]:
        members = chroms.get(chrom, [])
        idxs = [genes.index((nm, GENES[nm])) for nm in members]
        sub = matrix[np.ix_(idxs, idxs)]
        mask = ~np.isnan(sub)
        if mask.any():
            gcf = float(np.exp(-sub[mask].var() * len(sub) / 100.0))
        else:
            gcf = 0.0
        chrom_gcf[chrom] = gcf
        print(f"  染色体 {chrom}: GCF ≈ {gcf:.4f}  ({len(members)} 基因座)")
    print()

    # 整体 GCF
    all_g = matrix[~np.isnan(matrix)].flatten()
    overall_gcf = float(np.exp(-all_g.var() * len(all_g) / 100.0))
    print(f"整体 GCF = {overall_gcf:.4f}  (越接近1 = 基因组高度耦合)")
    print()

    # ─── 输出 JSON 供前端渲染 ───
    output = {
        "matrix": matrix.tolist(),
        "pairs": [
            {"a": a, "b": b, "chrom": c1, "r": r, "gij": g, "Eij": (None if np.isnan(e) else e)}
            for a,b,c1,c2,r,g,e in pairs
        ],
        "genes": [{"name":nm, "chrom":GENES[nm]["chrom"], "pos":GENES[nm]["pos"],
                   "trait":GENES[nm]["trait"]} for nm,_ in genes],
        "top_pairs": [
            {"a":a, "b":b, "r":r, "gij":g, "Eij":E}
            for a,b,r,g,E in sorted_pairs[:15]
        ],
        "chrom_gcf": chrom_gcf,
        "overall_gcf": overall_gcf,
    }
    Path("results/gcf_data.json").parent.mkdir(parents=True, exist_ok=True)
    Path("results/gcf_data.json").write_text(json.dumps(output, ensure_ascii=False, indent=2))
    print("数据已写入 results/gcf_data.json")
    return output

if __name__ == "__main__":
    main()
