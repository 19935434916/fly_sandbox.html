"""
GPU 加速 LIF 神经网络仿真 v2 — 百万神经元规模
三种后端自动选择: CUDA (torch) > CPU (torch) > NumPy 纯向量化

设计要点:
  - 事件驱动突触传播: 只传播有尖峰的源神经元
  - 膜电位更新全向量化: dV = (-(V-V_rest)/tau + Isyn + Iext) * dt
  - 不应期 refractory 用整型计数器
  - 突触传播: Isyn[CT] += CW * spike[src]
    numpy: np.add.at (对重复索引累加)
    torch: index_add_ (GPU 原子加)

使用:
  python gpu_sim.py --neurons 1000000 --syn-ratio 20 --duration 500
  python gpu_sim.py --benchmark                  # 1万/10万/100万 三档基准
  python gpu_sim.py --connectome ../data/connectome_demo.json
"""
import argparse
import json
import time
import numpy as np
from pathlib import Path

# ---------------------------------------------------------------------------
# 后端检测
# ---------------------------------------------------------------------------
def pick_backend():
    try:
        import torch
        if torch.cuda.is_available():
            return "torch", "cuda:0", torch.cuda.get_device_name(0)
        return "torch", "cpu", "CPU (torch)"
    except ImportError:
        return "numpy", "cpu", "CPU (numpy)"


BACKEND, DEVICE, DEVNAME = pick_backend()
torch = None
if BACKEND == "torch":
    import torch


class LIFPopulation:
    """一组 LIF 神经元 + 稀疏突触连接, 三后端统一接口"""

    def __init__(self, n_neurons, dt=0.1):
        self.n = n_neurons
        self.dt = dt
        self.V_REST, self.V_TH, self.V_RESET = -65.0, -50.0, -65.0
        self.tau, self.t_ref = 10.0, 2.0          # ms

        xp = torch if BACKEND == "torch" else np
        self.xp = xp
        dev = DEVICE if BACKEND == "torch" else "cpu"
        self.V = xp.full((n_neurons,), self.V_REST, dtype=xp.float32, device=dev)
        self.ref = xp.zeros((n_neurons,), dtype=xp.int32, device=dev)
        self.Isyn = xp.zeros((n_neurons,), dtype=xp.float32, device=dev)
        self.Iext = xp.zeros((n_neurons,), dtype=xp.float32, device=dev)
        self.CS = self.CT = self.CW = None
        self.total_spikes = 0
        self.I0 = None          # 持久外部输入 (每步重新施加)

    # ---- 连接组 ----
    def set_synapses(self, src, tgt, weight):
        xp = self.xp
        dev = DEVICE if BACKEND == "torch" else "cpu"
        self.CS = xp.asarray(src, device=dev)
        self.CT = xp.asarray(tgt, device=dev)
        self.CW = xp.asarray(weight, dtype=xp.float32, device=dev)
        self.n_syn = len(src)

    def set_input(self, i):
        dev = DEVICE if BACKEND == "torch" else "cpu"
        self.I0 = self.xp.asarray(i, dtype=self.xp.float32, device=dev)
        self.Iext = self.I0.clone() if BACKEND == "torch" else self.I0.copy()

    # ---- 单步 ----
    def step(self):
        xp = self.xp
        V, ref = self.V, self.ref

        # 1) 膜电位积分
        dV = (-(V - self.V_REST) / self.tau + self.Isyn + self.Iext) * self.dt
        V = V + dV

        # 2) 不应期递减; 不应期内强制复位
        ref = xp.where(ref > 0, ref - 1, 0)   # torch 2.14: maximum 不收 Python 标量, where 兼容两后端
        refrac = ref > 0
        V = xp.where(refrac, self.V_RESET, V)

        # 3) 阈值检测 (不在不应期)
        spike = (V >= self.V_TH) & (ref == 0)

        # 4) 复位 + 设定不应期
        V = xp.where(spike, self.V_RESET, V)
        ref = xp.where(spike, xp.full_like(ref, int(self.t_ref / self.dt)), ref)

        # 5) 突触传播 (事件驱动): Isyn[CT] += CW * spike[CS]
        if self.CS is not None:
            if BACKEND == "torch":
                src_act = spike.to(xp.float32)[self.CS]
                self.Isyn.zero_()
                if src_act.any():
                    self.Isyn.index_add_(0, self.CT, self.CW * src_act)
            else:
                self.Isyn.fill(0.0)
                src_act = spike[self.CS].astype(np.float32)
                if src_act.any():
                    np.add.at(self.Isyn, self.CT, self.CW * src_act)
        else:
            self.Isyn = xp.zeros_like(self.Isyn)

        self.V, self.ref = V, ref
        # 每步重置: Iext 恢复为持久输入 I0 (感觉驱动持续存在)
        self.Iext = (self.I0.clone() if self.I0 is not None and BACKEND == "torch"
                     else (self.I0.copy() if self.I0 is not None
                           else xp.zeros_like(self.Iext)))
        n_sp = int(spike.sum())
        self.total_spikes += n_sp
        return n_sp

    # ---- 仿真循环 (带进度条) ----
    def run(self, duration_ms, show_bar=True, bar_width=36):
        import sys
        n_steps = int(duration_ms / self.dt)
        t0 = time.perf_counter()
        bar_every = max(1, n_steps // 100)      # 进度条刷新粒度 1%
        spikes_at_last = 0
        for step in range(n_steps):
            self.step()
            if show_bar and (step % bar_every == 0 or step == n_steps - 1):
                frac = (step + 1) / n_steps
                filled = int(bar_width * frac)
                dt_step = (time.perf_counter() - t0) / (step + 1)
                eta = dt_step * (n_steps - step - 1)
                rate = (step + 1) / max(time.perf_counter() - t0, 1e-9)
                bar = "█" * filled + "░" * (bar_width - filled)
                sys.stderr.write(
                    f"\r  [{bar}] {frac*100:5.1f}%  "
                    f"{rate:,.0f} 步/s  ETA {eta:5.1f}s  "
                    f"尖峰 {self.total_spikes - spikes_at_last:,}")
                sys.stderr.flush()
        if show_bar:
            wall = time.perf_counter() - t0
            sys.stderr.write(
                f"\r  [{'█' * bar_width}] 100.0%  "
                f"{n_steps / wall:,.0f} 步/s  用时 {wall:.2f}s\n")
            sys.stderr.flush()
        wall = time.perf_counter() - t0
        return {
            "steps": n_steps,
            "wall_s": wall,
            "spikes": self.total_spikes,
            "steps_per_s": n_steps / wall if wall > 0 else 0,
            "realtime_factor": (n_steps * self.dt) / 1000.0 / wall if wall > 0 else 0,
        }


def random_synapses(n_neurons, syn_ratio, seed=42):
    """随机稀疏连接组 (Erdos-Renyi + 30% 近邻富集)"""
    rng = np.random.default_rng(seed)
    n_syn = int(n_neurons * syn_ratio)
    src = rng.integers(0, n_neurons, n_syn, dtype=np.int64)
    tgt = rng.integers(0, n_neurons, n_syn, dtype=np.int64)
    near = (src + rng.integers(-1000, 1001, n_syn)) % n_neurons
    tgt = np.where(rng.random(n_syn) < 0.30, near, tgt)
    w = rng.uniform(0.2, 0.9, n_syn).astype(np.float32)
    w[rng.random(n_syn) < 0.20] *= -1.0          # 20% 抑制
    return src, tgt, w


def benchmark(out_file=None):
    import sys
    lines = []
    lines.append("=" * 64)
    lines.append(f"百万神经元 LIF 仿真基准   后端: {BACKEND} @ {DEVNAME}")
    lines.append("=" * 64)
    for n, ratio in [(10_000, 100), (100_000, 100), (1_000_000, 20)]:
        pop = LIFPopulation(n, dt=0.1)
        src, tgt, w = random_synapses(n, ratio)
        pop.set_synapses(src, tgt, w)
        pop.set_input(np.random.exponential(2.5, n).astype(np.float32))
        mem = len(src) * 20 / 1048576
        lines.append(f"\n--- {n:,} 神经元 x {len(src):,} 突触 (约 {mem:.0f} MB) ---")
        print(lines[-1], file=sys.stderr, flush=True)
        r = pop.run(500.0)
        lines.append(f"    步数 {r['steps']:,} | 墙钟 {r['wall_s']:.2f}s | 尖峰 {r['spikes']:,}")
        lines.append(f"    吞吐 {r['steps_per_s']:,.0f} 步/s | 实时 {r['realtime_factor']:.1f}x | "
                     f"{n * r['steps_per_s']/1e6:.1f} G神经步/s")
        print(lines[-2], file=sys.stderr, flush=True)
        print(lines[-1], file=sys.stderr, flush=True)
        del pop, src, tgt, w
    if out_file:
        Path(out_file).write_text("\n".join(lines), encoding="utf-8")
        print(f"结果已写入 {out_file}", file=sys.stderr, flush=True)


def run_connectome(path, duration=1000.0):
    print(f"加载连接组: {path}")
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    m = data["meta"]
    pop = LIFPopulation(m["n_neurons"], dt=0.1)
    pop.set_synapses(np.array(data["synapses"]["src"]),
                     np.array(data["synapses"]["tgt"]),
                     np.array(data["synapses"]["w"], dtype=np.float32))
    sensory = [x["id"] for x in data["neurons"] if x["layer"] == 0]
    i_ext = np.zeros(m["n_neurons"], dtype=np.float32)
    # V_ss = V_rest + I*tau → I≈2.0 使感觉神经元处于发放区 (阈值 -50mV)
    i_ext[sensory] = np.random.exponential(2.0, len(sensory)).astype(np.float32)
    pop.set_input(i_ext)
    print(f"  {m['n_neurons']:,} 神经元 / {m['n_synapses']:,} 突触 / "
          f"{len(sensory):,} 感觉入口")
    r = pop.run(duration)
    print(f"  {r['steps']:,} 步 / {r['wall_s']:.2f}s / {r['spikes']:,} 尖峰 / "
          f"实时 {r['realtime_factor']:.1f}x")
    return r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--neurons", type=int, default=1_000_000)
    ap.add_argument("--syn-ratio", type=int, default=100)
    ap.add_argument("--dt", type=float, default=0.1)
    ap.add_argument("--duration", type=float, default=1000.0)
    ap.add_argument("--connectome")
    ap.add_argument("--benchmark", action="store_true")
    ap.add_argument("--out", default="../results/benchmark.txt", help="基准结果输出文件")
    ap.add_argument("--seed", type=int, default=42)
    args = ap.parse_args()

    if args.benchmark:
        Path(args.out).parent.mkdir(parents=True, exist_ok=True)
        benchmark(args.out)
        return
    if args.connectome:
        run_connectome(args.connectome, args.duration)
        return

    print(f"后端: {BACKEND} @ {DEVNAME}")
    pop = LIFPopulation(args.neurons, args.dt)
    src, tgt, w = random_synapses(args.neurons, args.syn_ratio, args.seed)
    pop.set_synapses(src, tgt, w)
    pop.set_input(np.random.exponential(8.0, args.neurons).astype(np.float32))
    print(f"{args.neurons:,} 神经元 / {len(src):,} 突触 / {args.duration} ms")
    r = pop.run(args.duration)
    print(f"完成: {r['wall_s']:.2f}s | {r['spikes']:,} 尖峰 | "
          f"{r['steps_per_s']:,.0f} 步/s | 实时 {r['realtime_factor']:.1f}x")


if __name__ == "__main__":
    main()
