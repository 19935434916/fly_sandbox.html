#!/usr/bin/env python3
"""
LCF 四维遗传超立方体
====================
将连锁耦合函数 LCF 投影到四维空间，生成 HTML 可视化页面。
每个基因座是一个顶点，耦合强度 gij 编码为第四维深度。
"""

import json
import numpy as np
from pathlib import Path

# 基因座数据
GENES = [
    ("X", "y",    0.0,   "body"),
    ("X", "w",    1.5,   "eye"),
    ("X", "cv",  13.7,   "wing"),
    ("X", "Pr",  37.7,   "eye"),
    ("X", "f",   56.0,   "wing"),
    ("X", "sn",  71.2,   "brist"),
    ("2", "L",   11.0,   "brist"),
    ("2", "Dicha",28.0,  "brist"),
    ("2", "vg",  67.0,   "wing"),
    ("2", "bw", 104.5,   "eye"),
    ("3", "ca",  11.0,   "eye"),
    ("3", "L23tc",17.5,  "brist"),
    ("3", "st",  44.0,   "eye"),
    ("3", "ct",  53.5,   "wing"),
    ("3", "e",   70.7,   "body"),
    ("4", "ey",   0.2,   "eye"),
    ("4", "Pp",   3.0,   "eye"),
    ("4", "L4",  18.0,   "brist"),
    ("4", "Q",   35.0,   "body"),
    ("4", "Sc",  49.0,   "brist"),
]

def kosambi(d):
    return 0.5 * np.tanh(2 * d / 100)

def lcf(d):
    r = kosambi(d) if d > 0 else 0
    return (1 - r) ** 2

# 计算耦合矩阵
n = len(GENES)
matrix = np.full((n, n), np.nan)
for i in range(n):
    matrix[i, i] = 1.0
    for j in range(i+1, n):
        if GENES[i][0] != GENES[j][0]:
            matrix[i, j] = matrix[j, i] = 0.25
            continue
        d = abs(GENES[j][2] - GENES[i][2])
        g = lcf(d)
        matrix[i, j] = matrix[j, i] = g

# 输出 JSON
data = {
    "genes": [{"name": g[1], "chrom": g[0], "pos": g[2], "trait": g[3]} for g in GENES],
    "matrix": matrix.tolist(),
    "gcc": float(np.nanmean(matrix[~np.isnan(matrix)])),
}
Path("results/lcf_4d.json").write_text(json.dumps(data, ensure_ascii=False, indent=2))
print(f"数据已写入: results/lcf_4d.json")
print(f"GCC = {data['gcc']:.4f}")
