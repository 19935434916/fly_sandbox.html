"""
验证：左右拓扑分离的连接组能否涌现趋光行为
果蝇在 3D 空间飞行，朝向由左右 DN 放电率差驱动
"""

import numpy as np

RNG = np.random.RandomState(7)

# ---------- 神经元定义 ----------
# side: 'R' = 右视野/右侧通路, 'L' = 左视野/左侧通路
neurons = {}


def add(ntype, side, count):
    for i in range(count):
        nid = f"{ntype}_{side}_{i}"
        neurons[nid] = {"type": ntype, "side": side,
                        "V": -65.0, "ref": 0, "Isyn": 0.0, "Iext": 0.0}


# 光感受器: R1,R2,R3 = 右视野 | R4,R5,R6 = 左视野
for rt in ["R1", "R2", "R3"]:
    add(rt, "R", 6)
for rt in ["R4", "R5", "R6"]:
    add(rt, "L", 6)

for side in ["L", "R"]:
    add("MeND", side, 15)
    add("Tm1", side, 8)
    add("Tm2", side, 8)
    add("Tm3", side, 8)
    add("LobColumn", side, 20)
    add("Tu1", side, 15)
    add("AOTU", side, 12)

# 下行神经元 (运动输出)
add("DNge1", "L", 5)
add("DNam1", "L", 5)
add("DNge104", "R", 5)
add("DNg13", "R", 5)

DN_LEFT = ("DNge1", "DNam1")
DN_RIGHT = ("DNge104", "DNg13")

# ---------- 连接组 (同侧拓扑分离) ----------
conns = []


def connect(src_types, src_side, tgt_type, tgt_side, w_range, n_each=3):
    srcs = [n for n, d in neurons.items() if d["type"] in src_types and d["side"] == src_side]
    tgts = [n for n, d in neurons.items() if d["type"] == tgt_type and d["side"] == tgt_side]
    if not srcs or not tgts:
        return
    k = min(n_each, len(tgts))
    for s in srcs:
        for ci in RNG.choice(len(tgts), size=k, replace=False):
            conns.append((s, tgts[ci], RNG.uniform(*w_range)))


# 光感受器 -> MeND (同侧)
connect(["R1", "R2", "R3"], "R", "MeND", "R", (0.5, 0.9), n_each=6)
connect(["R4", "R5", "R6"], "L", "MeND", "L", (0.5, 0.9), n_each=6)

for side in ["L", "R"]:
    connect(["MeND"], side, "Tm1", side, (0.3, 0.7), n_each=4)
    connect(["MeND"], side, "Tm2", side, (0.3, 0.7), n_each=4)
    connect(["MeND"], side, "Tm3", side, (0.3, 0.7), n_each=4)
    connect(["Tm1", "Tm2", "Tm3"], side, "LobColumn", side, (0.3, 0.7), n_each=4)
    connect(["LobColumn"], side, "Tu1", side, (0.3, 0.7), n_each=4)
    connect(["Tu1"], side, "AOTU", side, (0.3, 0.7), n_each=4)
    dn_types = ["DNge1", "DNam1"] if side == "L" else ["DNge104", "DNg13"]
    for dn in dn_types:
        connect(["AOTU"], side, dn, side, (0.45, 0.85), n_each=5)

# ---------- LIF 参数 ----------
V_REST, V_TH, V_RESET = -65.0, -50.0, -65.0
TAU, T_REF = 10.0, 2

vis = np.zeros(6)


def set_visual(azimuth, elevation=0.35, intensity=1.0):
    """azimuth: 光源相对果蝇朝向的方位角, 正=右, 负=左"""
    vis[0] = intensity * max(0, np.sin(azimuth + 0.5))       # R1 右视野
    vis[1] = intensity * max(0, np.sin(azimuth + 0.25))      # R2
    vis[2] = intensity * max(0, np.sin(azimuth))             # R3
    vis[3] = intensity * max(0, np.sin(-azimuth + 0.5))      # R4 左视野
    vis[4] = intensity * max(0, np.sin(-azimuth + 0.25))     # R5
    vis[5] = intensity * max(0, np.sin(-azimuth))            # R6
    hf = max(0.3, np.sin(elevation + 0.5))
    for i in range(6):
        vis[i] *= hf


def step_network():
    """推进一个神经时间步, 返回左右 DN 放电数"""
    pri_map = {"R1": 0, "R2": 1, "R3": 2, "R4": 3, "R5": 4, "R6": 5}
    for nid, d in neurons.items():
        if d["type"] in pri_map:
            d["Iext"] = RNG.exponential(1.1) + vis[pri_map[d["type"]]] * 30.0

    spikes = []
    for nid, d in neurons.items():
        if d["ref"] > 0:
            d["ref"] -= 1
            d["V"] = V_RESET
            continue
        total = d["Isyn"] + d["Iext"]
        d["V"] += (-(d["V"] - V_REST) / TAU + total)
        d["Isyn"] = 0.0
        d["Iext"] = 0.0
        if d["V"] >= V_TH:
            d["V"] = V_RESET
            d["ref"] = T_REF
            spikes.append(nid)

    sset = set(spikes)
    for s, t, w in conns:
        if s in sset:
            neurons[t]["Isyn"] += w * 9.0

    left = sum(1 for n in spikes if neurons[n]["type"] in DN_LEFT)
    right = sum(1 for n in spikes if neurons[n]["type"] in DN_RIGHT)
    return left, right


# ---------- 3D 飞行 ----------
ROOM = 9.0   # 房间半宽
LIGHT = np.array([4.5, 0.5, 4.5])


def run(steps=3000, seed=7):
    global RNG
    RNG = np.random.RandomState(seed)
    for d in neurons.values():
        d["V"], d["ref"], d["Isyn"], d["Iext"] = V_REST, 0, 0.0, 0.0

    pos = np.array([0.0, 0.0, 0.0])
    heading = 0.0            # 0 = +z 方向
    trail = []
    dists = []

    for t in range(steps):
        # 光源相对方位角
        rel = LIGHT - pos
        az = heading - np.arctan2(rel[0], rel[2])   # 正=光在右; 右手系朝+z时右为-x
        az = (az + np.pi) % (2 * np.pi) - np.pi      # 归一到 [-pi, pi]
        el = np.arctan2(rel[1], max(np.linalg.norm(rel[:2]), 0.1))

        set_visual(az, el, intensity=1.0)

        # 多子步累积放电 (提高转向信噪比)
        L = R = 0
        for _ in range(4):
            l, r = step_network()
            L += l
            R += r

        total = L + R
        yaw = (L - R) / total if total > 0 else 0.0     # 正 = 左转
        throttle = min(1.0, total / 14.0)
        pitch = np.clip((el) * 0.8, -1, 1) * throttle

        # 积分
        heading += yaw * 0.035
        speed = 0.020 + throttle * 0.030
        pos[0] += np.sin(heading) * speed
        pos[2] += np.cos(heading) * speed
        pos[1] += pitch * 0.03
        pos[1] += np.sin(t * 0.13) * 0.004              # 轻微振翅起伏

        # 边界反弹
        for i in range(3):
            if pos[i] > ROOM:
                pos[i] = ROOM
                heading += np.pi * 0.8
            elif pos[i] < -ROOM:
                pos[i] = -ROOM
                heading += np.pi * 0.8
        pos[1] = np.clip(pos[1], -ROOM * 0.4, ROOM * 0.5)

        trail.append(pos.copy())
        dists.append(np.linalg.norm(LIGHT - pos))

    return np.array(trail), np.array(dists)


if __name__ == "__main__":
    print("=" * 62)
    print("果蝇飞行验证 - 趋光性是否由连接组涌现")
    print("=" * 62)
    print(f"神经元: {len(neurons)} | 突触: {len(conns)}")
    print(f"光源位置: ({LIGHT[0]}, {LIGHT[1]}, {LIGHT[2]})")
    print(f"果蝇起点: (0, 0, 0)   初始距离: {np.linalg.norm(LIGHT):.2f}")
    print()

    trail, dists = run(3000)

    print(f"{'步数':>6} | {'到光源距离':>10} | 位置 (x, y, z)")
    print("-" * 62)
    for i in range(0, 3000, 375):
        p = trail[i]
        print(f"{i:6d} | {dists[i]:10.2f} | ({p[0]:+5.2f}, {p[1]:+5.2f}, {p[2]:+5.2f})")

    print()
    print("=" * 62)
    first = dists[:300].mean()
    last = dists[-300:].mean()
    print(f"前 300 步平均距离: {first:.2f}")
    print(f"后 300 步平均距离: {last:.2f}")
    print(f"最近距离: {dists.min():.2f}  (初始 {np.linalg.norm(LIGHT):.2f})")
    if last < first:
        print(f">> 趋光性涌现: 距离缩短 {first - last:.2f} ({(1-last/first)*100:.0f}%)")
    else:
        print(">> 未涌现趋光 (距离未缩短)")
    print("=" * 62)
