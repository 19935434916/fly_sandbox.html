/* 20 基因座扩展遗传系统测试 */
const fs = require('fs');
const html = fs.readFileSync(__dirname + '/fly_sandbox.html', 'utf8');
const src = html.match(/<script>([\s\S]*?)<\/script>/)[1];
const genPart = src.substring(0, src.indexOf('/* ================= 连接组模板'));

const TESTS = `
// === 测试 1: 基因座数量 ===
let pass=0, fail=0;
const nLoci=Object.keys(GENE).length;
console.log('[T01] 基因座总数 =', nLoci, nLoci===20?'PASS':'FAIL');
nLoci===20?pass++:fail++;

// === 测试 2: 染色体分配 ===
const expect={X:6,'2':4,'3':5,'4':5};
let ok=true;
for(const c of CHROM) if(CGENES[c].length!==expect[c]) ok=false;
console.log('[T02] 染色体基因分配 X:6 2:4 3:5 4:5 =', CGENES.X.length, CGENES['2'].length, CGENES['3'].length, CGENES['4'].length, ok?'PASS':'FAIL');
ok?pass++:fail++;

// === 测试 3: 图距单调排序 ===
ok=true;
for(const c of CHROM) for(let i=1;i<CGENES[c].length;i++)
  if(GENE[CGENES[c][i]].pos<=GENE[CGENES[c][i-1]].pos) ok=false;
console.log('[T03] 图距排序单调递增 =', ok?'PASS':'FAIL');
ok?pass++:fail++;

// === 测试 4: Kosambi 重组率范围 (0,0.5) ===
ok=true;
for(const c of CHROM) for(const r of RF[c]) if(!(r>0&&r<0.5)) ok=false;
console.log('[T04] 所有重组率 in (0,0.5) =', ok?'PASS':'FAIL');
ok?pass++:fail++;

// === 测试 5: 雄性无交换 ===
let maleRecomb=false;
for(let t=0;t<2000;t++){
  const g2=mkGenome('M');
  g2['2']=[{vg:'vg',bw:'bw',L:'L',Dicha:'Dicha'},{vg:'vg',bw:'+',L:'+',Dicha:'+'}];
  const gm=gamete(g2);
  const h=g2['2'][0],h2=g2['2'][1];
  const isH1=CGENES['2'].every(k=>gm['2'][k]===h[k]);
  const isH2=CGENES['2'].every(k=>gm['2'][k]===h2[k]);
  if(!isH1&&!isH2) maleRecomb=true;
}
console.log('[T05] 雄性完全连锁(2000次无重组) =', !maleRecomb?'PASS':'FAIL');
!maleRecomb?pass++:fail++;

// === 测试 6: 雌性交换发生 ===
let femaleRecomb=false;
for(let t=0;t<5000;t++){
  const g2=mkGenome('F');
  g2['3']=[{st:'st',e:'e',ca:'ca',ct:'ct','L(2,3)tc':'L(2,3)tc'},{st:'+',e:'+',ca:'+',ct:'+','L(2,3)tc':'+'}];
  const gm=gamete(g2);
  const h=g2['3'][0];
  const allH1=CGENES['3'].every(k=>gm['3'][k]===h[k]);
  if(!allH1 && !CGENES['3'].every(k=>gm['3'][k]==='+')) femaleRecomb=true;
}
console.log('[T06] 雌性交换发生(5000次) =', femaleRecomb?'PASS':'FAIL');
femaleRecomb?pass++:fail++;

// === 测试 7: 表型判定 - 纯合隐性 ===
const gMut=mkGenome('F',{vg:'vg',st:'st',y:'y'});
gMut['2']=[{vg:'vg',bw:'+',L:'+',Dicha:'+'},{vg:'vg',bw:'+',L:'+',Dicha:'+'}];
const pMut=pheno(gMut);
console.log('[T07] vg/vg 纯合 -> 残翅 =', pMut.vg?'PASS':'FAIL');
pMut.vg?pass++:fail++;

// === 测试 8: X 连锁雄性半合子 ===
const gM=mkGenome('M',{w:'w'});
console.log('[T08] 雄性 X 半合子 w -> 白眼 =', pheno(gM).eye==='白眼'?'PASS':'FAIL');
pheno(gM).eye==='白眼'?pass++:fail++;

// === 测试 9: X 连锁雌性杂合不表现 (手动构造真杂合子) ===
const gF=mkGenome('F');
gF.X[0]['w']='w'; gF.X[1]['w']='+';
console.log('[T09] 雌性杂合 w/+ -> 非白眼 =', pheno(gF).eye!=='白眼'?'PASS':'FAIL', '(实际:'+pheno(gF).eye+')');
pheno(gF).eye!=='白眼'?pass++:fail++;

// === 测试 10: w 上位 st/bw ===
const gW=mkGenome('F',{w:'w',st:'st',bw:'bw'});
gW['2']=[{vg:'+',bw:'bw',L:'+',Dicha:'+'},{vg:'+',bw:'bw',L:'+',Dicha:'+'}];
const pW=pheno(gW);
console.log('[T10] w 上位 st/bw -> 白眼 =', pW.eye==='白眼'?'PASS':'FAIL', '(实际:'+pW.eye+')');
pW.eye==='白眼'?pass++:fail++;

// === 测试 11: st+ca 双突变 -> 橙眼 ===
const gSC=mkGenome('F',{st:'st',ca:'ca'});
gSC['3']=[{st:'st',e:'+',ca:'ca',ct:'+','L(2,3)tc':'+'},{st:'st',e:'+',ca:'ca',ct:'+','L(2,3)tc':'+'}];
const pSC=pheno(gSC);
console.log('[T11] st+ca 双纯合 -> 橙眼 =', pSC.eye==='橙眼'?'PASS':'FAIL', '(实际:'+pSC.eye+')');
pSC.eye==='橙眼'?pass++:fail++;

// === 测试 12: 20 基因座减数分裂完整往返 ===
let ok12=true, firstBad12='';
for(let t=0;t<500;t++){
  const mum=mkGenome('F'), dad=mkGenome('M');
  const baby=makeBaby({genome:mum},{genome:dad});
  for(const k of CGENES['X']){
    if(baby.X[0][k]===undefined){ok12=false;if(!firstBad12)firstBad12='X0/'+k;}
    if(baby.sex==='F'&&baby.X[1][k]===undefined){ok12=false;if(!firstBad12)firstBad12='X1/'+k+'/F';}
  }
  for(const c of ['2','3','4']) for(const k of CGENES[c]){
    if(baby[c][0][k]===undefined){ok12=false;if(!firstBad12)firstBad12=c+'0/'+k;}
    if(baby[c][1][k]===undefined){ok12=false;if(!firstBad12)firstBad12=c+'1/'+k;}
  }
  if(baby.sex==='M'&&baby.X[1]!==null){ok12=false;if(!firstBad12)firstBad12='maleX1notnull';}
}
console.log('[T12] 500次繁殖基因组完整性 =', ok12?'PASS':'FAIL', firstBad12?'(首个失败:'+firstBad12+')':'');
ok12?pass++:fail++;

// === 测试 13: 表型->适合度 新增字段 ===
const fit=fitness(pMut,'F');
const ok13 = fit.vis!==undefined&&fit.fly!==undefined&&fit.cou!==undefined&&fit.hz!==undefined&&fit.eyeCol&&fit.bodyCol&&fit.wingCol;
console.log('[T13] fitness 返回 eyeCol/bodyCol/wingCol =', ok13?'PASS':'FAIL');
ok13?pass++:fail++;

// === 测试 14: 残翅飞行适合度 0.16 ===
console.log('[T14] vg 残翅 fly=0.16 =', fit.fly===0.16?'PASS':'FAIL');
fit.fly===0.16?pass++:fail++;

// === 测试 15: traitTag 输出 ===
const tag=traitTag(pMut);
const ok15 = tag.includes('残翅')&&tag.includes('朱红眼')&&tag.includes('黄身');
console.log('[T15] traitTag 多突变标签 =', ok15?'PASS':'FAIL', '(实际:'+tag+')');
ok15?pass++:fail++;

// === 测试 16: 选择压下 vg 频率下降 ===
let qSum=0;
for(let trial=0;trial<20;trial++){
  let q=0.5;
  for(let gen=0;gen<50;gen++){
    const qBar=(q*q*0.16+q*(1-q)*1)/( (q*q*0.16+2*q*(1-q)*1+(1-q)*(1-q)*1) );
    q=Math.min(0.99,Math.max(0.01,qBar*q+rnd()*0.02-0.01));
  }
  qSum+=q;
}
const qMean=qSum/20;
console.log('[T16] 选择压下 vg 频率下降 (q=0.5->'+qMean.toFixed(2)+') =', qMean<0.45?'PASS':'FAIL');
qMean<0.45?pass++:fail++;

// === 测试 17: 新增眼色基因 Pr/Pp/ca 独立遗传 ===
// Pr 在 X, Pp 在 4, ca 在 3 —— 自由组合: 联合频率 ≈ 边缘乘积
let nPrPp=0, nPr=0, nPp=0;
const NT=4000;
for(let t=0;t<NT;t++){
  const mum=mkGenome('F'), dad=mkGenome('M');
  const baby=makeBaby({genome:mum},{genome:dad});
  // 强制携带: 人为设置纯合
  const m2=mkGenome('F',{Pr:'Pr'});
  m2['4']=[{ey:'+',Pp:'Pp','L(4)':'+',Q:'+',Sc:'+'},{ey:'+',Pp:'Pp','L(4)':'+',Q:'+',Sc:'+'}];
  const m3=mkGenome('M',{Pr:'Pr'});
  m3['4']=[{ey:'+',Pp:'Pp','L(4)':'+',Q:'+',Sc:'+'},{ey:'+',Pp:'Pp','L(4)':'+',Q:'+',Sc:'+'}];
  const b2=makeBaby({genome:m2},{genome:m3});
  const pp=pheno(b2);
  if(pp.Pr) nPr++;
  if(b2.sex==='F'&&pp.Pp) nPp++;
  if(b2.sex==='F'&&pp.Pr&&pp.Pp) nPrPp++;
}
// 粗验: Pr X连锁雄性全表达; Pp 4号纯合全表达(雌雄)
console.log('[T17] Pr X连锁 + Pp 4号纯合 联合表达 =', nPr>0?'PASS':'FAIL', '(Pr:'+nPr+'/'+NT+')');
nPr>0?pass++:fail++;

// === 测试 18: 第4染色体无交换(真实果蝇特征) ===
let ch4Recomb=false;
for(let t=0;t<3000;t++){
  const g2=mkGenome('F');
  g2['4']=[{ey:'ey',Pp:'Pp','L(4)':'L(4)',Q:'Q',Sc:'Sc'},{ey:'+',Pp:'+', 'L(4)':'+',Q:'+',Sc:'+'}];
  const gm=gamete(g2);
  const h=g2['4'][0],h2=g2['4'][1];
  const isH1=CGENES['4'].every(k=>gm['4'][k]===h[k]);
  const isH2=CGENES['4'].every(k=>gm['4'][k]===h2[k]);
  if(!isH1&&!isH2) ch4Recomb=true;
}
console.log('[T18] 第4染色体极小无交换(3000次) =', !ch4Recomb?'PASS':'FAIL');
!ch4Recomb?pass++:fail++;

console.log('========================================');
console.log('总计: '+pass+' PASS / '+fail+' FAIL / '+(pass+fail)+' 项');
process.exit(fail>0?1:0);
`;

eval(genPart.replace('"use strict";', '') + TESTS);
