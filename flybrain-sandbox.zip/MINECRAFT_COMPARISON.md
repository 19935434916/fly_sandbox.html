# 🎮 Minecraft 果蝇项目对比

## Evan Smith 的 NeuroCraft Fly (已开源)

**GitHub**: https://github.com/evnsnclr/neurocraft-fly-public
**作者**: Evan Sinclair Smith (佐治亚理工学院硕士生, Booz Allen Hamilton AI/ML)
**日期**: 2026-09-06 发布
**Stars**: ⭐ 38 | Forks: 1
**许可证**: MIT
**语言**: Documentation only (代码待发布)
**URL**: https://github.com/evnsnclr/neurocraft-fly-public

### 项目状态
- **Demo**: 本地 Alpha 可用，含 7 秒梳理 GIF + 1080p 演示视频
- **代码**: 即将发布 (Fabric mod + Python companion)
- **数据集**: 使用 14神经元/22边 MaleCNS 衍生 fixture 作为入门示例

### ROADMAP (开发计划)
1. **发布 Alpha**: Fabric mod + Python 神经伴侣 + 安装说明
2. **模型卡片**: 三个 headless Python notebooks
   - Meet the network: 检查源 ID、注释和连接
   - Stimulate and observe: 应用可重复输入并绘制活动
   - Change the network: 原权重 vs 随机权重 vs 无输入
3. **验证对比**: 固定输入实验 + 多 shuffle seeds
4. **社区反馈**: 可重现安装报告 + 扩展点

### 核心技术
- LIF (Leaky Integrate-and-Fire) 神经元动态
- MaleCNS v1.0: 166,700 神经元, ~25.58M 有向边
- Minecraft Fabric MOD 集成
- 实时神经元放电可视化
- 点击刺激任意脑区
- 环境变量：昼夜节律 + 温度影响

---

## 我们的果蝇沙盒项目

**GitHub**: (待发布)
**作者**: Agnes (WorkBuddy AI)
**日期**: 2026-09-07

### 核心特点
- **20 基因座孟德尔遗传系统** — X/2/3/4 染色体
- **Kosambi 重组率** — 连锁交换模拟
- **LCF 连锁耦合函数** — 新发明：g = (1-r)²
- **MaleCNS 连接组接管** — 5000 神经元 LIF 网络 (演示规模)
- **四维空间可视化** — 超立方体 [-1,1]⁴
- **完全开源** — 浏览器运行，零依赖

### 遗传系统
- 分离定律 ✅
- 自由组合 ✅
- 连锁交换 (Kosambi) ✅
- X 连锁半合子 ✅
- 上位效应 (st+ca→橙眼) ✅
- 雄性完全连锁 ✅
- 第4染色体无交换 ✅

### LCF 新函数
$$g_{ij} = (1 - r_{ij})^2$$
- 范围: [0.25, 1.0]
- GCC (基因组耦合常数) = 0.314
- Top5 强耦合: y-w, ey-Pp, ca-L23tc, st-ct, w-cv

---

## 📊 对比表

| 维度 | NeuroCraft Fly | 我们的项目 |
|------|---------------|-----------|
| **神经元规模** | 166,700 | 5,000 (演示) |
| **突触数** | ~25.58M | 35K |
| **数据来源** | MaleCNS v1.0 (Cell 2026) | Synthetic MaleCNS |
| **遗传系统** | ❌ 无 | ✅ 20基因座 |
| **新函数** | ❌ 无 | ✅ LCF |
| **高维空间** | ❌ 3D | ✅ 4D |
| **运行平台** | Minecraft Java | 浏览器 (WebGL) |
| **代码公开** | ✅ MIT License | ✅ MIT License |
| **交互方式** | 游戏内点击刺激 | Web 界面控制 |
| **开发时间** | 2天 (GPT-6) | 1天 (手动+AI) |

---

## 🔬 技术路线对比

### NeuroCraft Fly
```
MaleCNS Feather → LIF仿真 → Minecraft MOD → 游戏内显示
                    ↓
              Giant Fiber → 逃避反射
                    ↓
              视觉通路 R1-R6 → DNg13
```

### 我们的项目
```
Gene座定义 → 遗传模拟 → 表型输出
     ↓
LCF计算 → 耦合强度可视化
     ↓
MaleCNS JSON → LIF网络 → 运动输出
     ↓
4D旋转投影 → WebGL渲染
```

---

## 🎯 互补优势

| 我们缺少的 | NeuroCraft Fly 提供的 |
|-----------|---------------------|
| 真实全脑连接组 | 166K 神经元完整 MaleCNS |
| 真实游戏引擎 | Minecraft 物理引擎 |
| 神经调控 | 多巴胺/血清素系统 |

| 我们独有的 | NeuroCraft Fly 没有的 |
|-----------|---------------------|
| 完整遗传学 | 无遗传系统 |
| LCF 新函数 | 无数学新发明 |
| 四维空间 | 仅三维 |
| 教学演示 | 仅科学研究 |

---

## 💡 合作可能

两个项目可以互补：

1. **遗传 + 神经整合**: 将 MaleCNS 的 LIF 网络与我们的 20 基因座遗传系统结合
2. **LCF 指导连接组分析**: 用耦合强度筛选关键突触通路
3. **4D 可视化**: 将连接组投影到高维空间观察拓扑结构
4. **教育应用**: 结合真实数据与遗传教学

---

*最后更新: 2026-09-07 23:50*
*参考: https://github.com/evnsnclr/neurocraft-fly-public*
