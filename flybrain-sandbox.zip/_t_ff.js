/* 快进(跳代演化)功能无头测试: 驱动 ffChunk 直到 generation 达标 */
const fs = require('fs');
const html = fs.readFileSync(__dirname + '/fly_sandbox.html', 'utf8');
const src = html.match(/<script>([\s\S]*?)<\/script>/)[1].replace('"use strict";', '');

/* ---- 浏览器环境 mock ---- */
function magicObj() {
  const f = function () { return magicObj(); };
  return new Proxy(f, {
    get: (t, p) => {
      if (p === Symbol.toPrimitive) return () => 0;
      if (p === 'length') return 0;
      return magicObj();
    },
    set: () => true,
    apply: () => magicObj(),
  });
}
function stubEl(id) {
  return {
    id, textContent: '', innerHTML: '', style: {}, disabled: false,
    width: 800, height: 600, children: [],
    classList: { toggle() {}, add() {}, remove() {} },
    appendChild(c) { this.children.push(c); },
    addEventListener() {}, getContext: () => magicObj(),
  };
}
const elCache = {};
global.document = {
  getElementById: (id) => elCache[id] || (elCache[id] = stubEl(id)),
  createElement: () => stubEl(),
  addEventListener() {}, body: { appendChild() {} },
};
global.window = { addEventListener() {}, devicePixelRatio: 1, location: {} };
global.requestAnimationFrame = () => 0;          // 不自动循环
// navigator / Audio 不需要 (依赖扫描未发现)

/* ---- 注入测试: 与源码同一作用域 ---- */
const TEST = `
;(function(){
  console.log('[setup] 初始种群', flies.length, '只 · 第', generation, '代 · MAX_FLIES', MAX_FLIES);
  // 手动加速键位检查
  if(typeof ffChunk!=='function') { console.log('FAIL ffChunk 未定义'); return; }
  const target = generation + 200;
  ff = {target:target, steps:0, t0:performance.now(), spawned:0};
  const t0 = performance.now();
  let chunks = 0, genSamples = [];
  while(ff && generation < ff.target && chunks < 2000000){
    ffChunk(); chunks++;
    if(chunks % 1000 === 0) console.log('  片'+chunks+': steps='+ff.steps+' gen='+generation+' 蝇='+flies.length+' dayT='+dayT.toFixed(0)+'天 born='+born);
    if(chunks % 200 === 0) genSamples.push([ff.steps, generation]);
    if(flies.length===0 && ff.spawned>50){ console.log('!! 种群反复灭绝'); break; }
  }
  const wall = (performance.now()-t0)/1000;
  const done = !ff || generation >= target;   // ffChunk 完成时会把 ff 置 null
  if(!done){
    console.log('FAIL 未达目标: 第', generation, '代 /', target, '·', ff.steps, '步 ·', wall.toFixed(1)+'s');
  } else {
    console.log('PASS 到达第', generation, '代 (目标', target + ') · 用时', wall.toFixed(1)+'s ·',
      Math.round(generation/ Math.max(wall,0.001)*10)/10, '代/s');
  }
  console.log('种群', flies.length, '只 · 出生', born, '· 死亡', died, '· 突变', muts);
  console.log('抽样 (步数→代):', genSamples.map(s=>s[0]+'→'+s[1]).join('  '));
  // 基因频率漂变验证: 统计活蝇 w 等位基因频率
  let wc=0, ac=0;
  for(const f of flies){ for(const h of (f.g?['X1','X2']:[])){
    const a=f.g[h]&&f.g[h]['w']; if(a){ if(a==='w') wc++; else ac++; } }}
  console.log('w 等位基因 (白眼) 频率样本:', wc, '/', wc+ac);
})();
`;

try {
  new Function('fs', '__dirname', src + TEST)(fs, __dirname);
} catch (e) {
  console.log('EXCEPTION:', e.message);
  console.log(e.stack.split('\n').slice(0, 4).join('\n'));
}
